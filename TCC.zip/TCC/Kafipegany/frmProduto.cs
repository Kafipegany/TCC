﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Model;
using Kafipegany.Entidades;

namespace Kafipegany
{
    public partial class frmProduto : Form
    {
        tb_produto tb = new tb_produto();
        ProdutoModel model = new ProdutoModel();
        public frmProduto()
        {
            InitializeComponent();
        }
        private void HabilitarCampos()
        {
            txtDescricao.Enabled = true;
            txtNome.Enabled = true;
            txtQuantidade.Enabled = true;
            txtValor.Enabled = true;
        }

        private void LimparCampos()
        {

            txtDescricao.Text = "";
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
        }

        private void Desabilitar()
        {
            txtNome.Enabled = false;
            txtDescricao.Enabled = false;
            txtValor.Enabled = false;
            txtQuantidade.Enabled = false;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            HabilitarCampos();
            txtNome.Focus();
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilitar();
            tb.Nm_produto = txtNome.Text;
            tb.Ds_produto = txtDescricao.Text;
            tb.Qt_produto = txtQuantidade.Text;
            tb.Vl_produto = txtValor.Text;

            if (txtNome.Text == "" && txtDescricao.Text == "" && txtQuantidade.Text == "" && txtValor.Text == "")
            {
                MessageBox.Show("Preencha os campos e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCampos();
            }
            else
            {
                if (txtNome.Text != "")
                {
                    if (txtDescricao.Text != "")
                    {
                        if (txtQuantidade.Text != "")
                        {
                            if (txtValor.Text != "")
                            {
                                if (txtcd.Text == "")
                                {
                                    model.InserirQuarto(tb);
                                    MessageBox.Show("O Produto foi Cadastrado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LimparCampos();
                                }
                                else
                                {
                                    tb.Cd_produto = int.Parse(txtcd.Text);
                                    model.AtualizarQuarto(tb);
                                    MessageBox.Show("O Produto foi Atualizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LimparCampos();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Preencha o campo de Valor  e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                HabilitarCampos();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Preencha o campo de Quantidade e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            HabilitarCampos();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o campo de Descrição e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        HabilitarCampos();
                    }

                }
                else
                {
                    MessageBox.Show("Preencha o campo de Nome do Produto e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HabilitarCampos();
                }
                
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {

        }
    }
}
