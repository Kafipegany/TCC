﻿namespace Kafipegany
{
    partial class frmCadastroHospede
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastroHospede));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.GridHospede = new System.Windows.Forms.DataGridView();
            this.cdclienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmclienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdrgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdcpfDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtnascimentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dstelefoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dscelularDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsestadocivilDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsveiculoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dstipoVeiculoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdCnpjDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdplacaVeiculoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdCepDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmestadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdInscricaoEstadualDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmcidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsenderecoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmbairroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbclienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kafipeganyDataSet = new Kafipegany.kafipeganyDataSet();
            this.pnlFormularios = new System.Windows.Forms.Panel();
            this.txtcd = new System.Windows.Forms.TextBox();
            this.txtCep = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtInscricaoEstadual = new System.Windows.Forms.TextBox();
            this.txtCnpj = new System.Windows.Forms.MaskedTextBox();
            this.txtPlaca = new System.Windows.Forms.TextBox();
            this.txtTipoVeiculo = new System.Windows.Forms.ComboBox();
            this.txtNomeMarcaVeiculo = new System.Windows.Forms.TextBox();
            this.pnlBotoes = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtEstadoCivil = new System.Windows.Forms.ComboBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCelular = new System.Windows.Forms.MaskedTextBox();
            this.txtTelefone = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDataNascimento = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCpf = new System.Windows.Forms.MaskedTextBox();
            this.txtRg = new System.Windows.Forms.MaskedTextBox();
            this.pnlPesquisa = new System.Windows.Forms.Panel();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.tbclienteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tb_clienteTableAdapter = new Kafipegany.kafipeganyDataSetTableAdapters.tb_clienteTableAdapter();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridHospede)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).BeginInit();
            this.pnlFormularios.SuspendLayout();
            this.pnlBotoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.pnlFormularios);
            this.panel5.Location = new System.Drawing.Point(74, 74);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1540, 793);
            this.panel5.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.GridHospede);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(480, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1060, 793);
            this.panel1.TabIndex = 3;
            // 
            // GridHospede
            // 
            this.GridHospede.AutoGenerateColumns = false;
            this.GridHospede.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.GridHospede.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridHospede.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridHospede.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridHospede.ColumnHeadersHeight = 50;
            this.GridHospede.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cdclienteDataGridViewTextBoxColumn,
            this.nmclienteDataGridViewTextBoxColumn,
            this.cdrgDataGridViewTextBoxColumn,
            this.cdcpfDataGridViewTextBoxColumn,
            this.dtnascimentoDataGridViewTextBoxColumn,
            this.dstelefoneDataGridViewTextBoxColumn,
            this.dscelularDataGridViewTextBoxColumn,
            this.dsemailDataGridViewTextBoxColumn,
            this.dsestadocivilDataGridViewTextBoxColumn,
            this.dsveiculoDataGridViewTextBoxColumn,
            this.dstipoVeiculoDataGridViewTextBoxColumn,
            this.cdCnpjDataGridViewTextBoxColumn,
            this.cdplacaVeiculoDataGridViewTextBoxColumn,
            this.cdCepDataGridViewTextBoxColumn,
            this.nmestadoDataGridViewTextBoxColumn,
            this.cdInscricaoEstadualDataGridViewTextBoxColumn,
            this.nmcidadeDataGridViewTextBoxColumn,
            this.dsenderecoDataGridViewTextBoxColumn,
            this.nmbairroDataGridViewTextBoxColumn});
            this.GridHospede.DataSource = this.tbclienteBindingSource;
            this.GridHospede.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.GridHospede.EnableHeadersVisualStyles = false;
            this.GridHospede.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            this.GridHospede.Location = new System.Drawing.Point(0, 0);
            this.GridHospede.Name = "GridHospede";
            this.GridHospede.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridHospede.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridHospede.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.GridHospede.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.GridHospede.Size = new System.Drawing.Size(1060, 793);
            this.GridHospede.TabIndex = 78;
            this.GridHospede.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridHospede_CellContentClick);
            // 
            // cdclienteDataGridViewTextBoxColumn
            // 
            this.cdclienteDataGridViewTextBoxColumn.DataPropertyName = "cd_cliente";
            this.cdclienteDataGridViewTextBoxColumn.HeaderText = "ID";
            this.cdclienteDataGridViewTextBoxColumn.Name = "cdclienteDataGridViewTextBoxColumn";
            this.cdclienteDataGridViewTextBoxColumn.Width = 35;
            // 
            // nmclienteDataGridViewTextBoxColumn
            // 
            this.nmclienteDataGridViewTextBoxColumn.DataPropertyName = "nm_cliente";
            this.nmclienteDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nmclienteDataGridViewTextBoxColumn.Name = "nmclienteDataGridViewTextBoxColumn";
            this.nmclienteDataGridViewTextBoxColumn.Width = 170;
            // 
            // cdrgDataGridViewTextBoxColumn
            // 
            this.cdrgDataGridViewTextBoxColumn.DataPropertyName = "cd_rg";
            this.cdrgDataGridViewTextBoxColumn.HeaderText = "RG";
            this.cdrgDataGridViewTextBoxColumn.Name = "cdrgDataGridViewTextBoxColumn";
            this.cdrgDataGridViewTextBoxColumn.Width = 135;
            // 
            // cdcpfDataGridViewTextBoxColumn
            // 
            this.cdcpfDataGridViewTextBoxColumn.DataPropertyName = "cd_cpf";
            this.cdcpfDataGridViewTextBoxColumn.HeaderText = "CPF";
            this.cdcpfDataGridViewTextBoxColumn.Name = "cdcpfDataGridViewTextBoxColumn";
            this.cdcpfDataGridViewTextBoxColumn.Width = 135;
            // 
            // dtnascimentoDataGridViewTextBoxColumn
            // 
            this.dtnascimentoDataGridViewTextBoxColumn.DataPropertyName = "dt_nascimento";
            this.dtnascimentoDataGridViewTextBoxColumn.HeaderText = "dt_nascimento";
            this.dtnascimentoDataGridViewTextBoxColumn.Name = "dtnascimentoDataGridViewTextBoxColumn";
            this.dtnascimentoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dstelefoneDataGridViewTextBoxColumn
            // 
            this.dstelefoneDataGridViewTextBoxColumn.DataPropertyName = "ds_telefone";
            this.dstelefoneDataGridViewTextBoxColumn.HeaderText = "ds_telefone";
            this.dstelefoneDataGridViewTextBoxColumn.Name = "dstelefoneDataGridViewTextBoxColumn";
            this.dstelefoneDataGridViewTextBoxColumn.Visible = false;
            // 
            // dscelularDataGridViewTextBoxColumn
            // 
            this.dscelularDataGridViewTextBoxColumn.DataPropertyName = "ds_celular";
            this.dscelularDataGridViewTextBoxColumn.HeaderText = "Celular";
            this.dscelularDataGridViewTextBoxColumn.Name = "dscelularDataGridViewTextBoxColumn";
            this.dscelularDataGridViewTextBoxColumn.Width = 130;
            // 
            // dsemailDataGridViewTextBoxColumn
            // 
            this.dsemailDataGridViewTextBoxColumn.DataPropertyName = "ds_email";
            this.dsemailDataGridViewTextBoxColumn.HeaderText = "ds_email";
            this.dsemailDataGridViewTextBoxColumn.Name = "dsemailDataGridViewTextBoxColumn";
            this.dsemailDataGridViewTextBoxColumn.Visible = false;
            // 
            // dsestadocivilDataGridViewTextBoxColumn
            // 
            this.dsestadocivilDataGridViewTextBoxColumn.DataPropertyName = "ds_estadocivil";
            this.dsestadocivilDataGridViewTextBoxColumn.HeaderText = "ds_estadocivil";
            this.dsestadocivilDataGridViewTextBoxColumn.Name = "dsestadocivilDataGridViewTextBoxColumn";
            this.dsestadocivilDataGridViewTextBoxColumn.Visible = false;
            // 
            // dsveiculoDataGridViewTextBoxColumn
            // 
            this.dsveiculoDataGridViewTextBoxColumn.DataPropertyName = "ds_veiculo";
            this.dsveiculoDataGridViewTextBoxColumn.HeaderText = "ds_veiculo";
            this.dsveiculoDataGridViewTextBoxColumn.Name = "dsveiculoDataGridViewTextBoxColumn";
            this.dsveiculoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dstipoVeiculoDataGridViewTextBoxColumn
            // 
            this.dstipoVeiculoDataGridViewTextBoxColumn.DataPropertyName = "ds_tipoVeiculo";
            this.dstipoVeiculoDataGridViewTextBoxColumn.HeaderText = "ds_tipoVeiculo";
            this.dstipoVeiculoDataGridViewTextBoxColumn.Name = "dstipoVeiculoDataGridViewTextBoxColumn";
            this.dstipoVeiculoDataGridViewTextBoxColumn.Visible = false;
            // 
            // cdCnpjDataGridViewTextBoxColumn
            // 
            this.cdCnpjDataGridViewTextBoxColumn.DataPropertyName = "cd_Cnpj";
            this.cdCnpjDataGridViewTextBoxColumn.HeaderText = "CNPJ";
            this.cdCnpjDataGridViewTextBoxColumn.Name = "cdCnpjDataGridViewTextBoxColumn";
            this.cdCnpjDataGridViewTextBoxColumn.Width = 140;
            // 
            // cdplacaVeiculoDataGridViewTextBoxColumn
            // 
            this.cdplacaVeiculoDataGridViewTextBoxColumn.DataPropertyName = "cd_placaVeiculo";
            this.cdplacaVeiculoDataGridViewTextBoxColumn.HeaderText = "cd_placaVeiculo";
            this.cdplacaVeiculoDataGridViewTextBoxColumn.Name = "cdplacaVeiculoDataGridViewTextBoxColumn";
            this.cdplacaVeiculoDataGridViewTextBoxColumn.Visible = false;
            // 
            // cdCepDataGridViewTextBoxColumn
            // 
            this.cdCepDataGridViewTextBoxColumn.DataPropertyName = "cd_Cep";
            this.cdCepDataGridViewTextBoxColumn.HeaderText = "cd_Cep";
            this.cdCepDataGridViewTextBoxColumn.Name = "cdCepDataGridViewTextBoxColumn";
            this.cdCepDataGridViewTextBoxColumn.Visible = false;
            // 
            // nmestadoDataGridViewTextBoxColumn
            // 
            this.nmestadoDataGridViewTextBoxColumn.DataPropertyName = "nm_estado";
            this.nmestadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.nmestadoDataGridViewTextBoxColumn.Name = "nmestadoDataGridViewTextBoxColumn";
            this.nmestadoDataGridViewTextBoxColumn.Width = 130;
            // 
            // cdInscricaoEstadualDataGridViewTextBoxColumn
            // 
            this.cdInscricaoEstadualDataGridViewTextBoxColumn.DataPropertyName = "cd_InscricaoEstadual";
            this.cdInscricaoEstadualDataGridViewTextBoxColumn.HeaderText = "Inscricão Estadual";
            this.cdInscricaoEstadualDataGridViewTextBoxColumn.Name = "cdInscricaoEstadualDataGridViewTextBoxColumn";
            this.cdInscricaoEstadualDataGridViewTextBoxColumn.Width = 180;
            // 
            // nmcidadeDataGridViewTextBoxColumn
            // 
            this.nmcidadeDataGridViewTextBoxColumn.DataPropertyName = "nm_cidade";
            this.nmcidadeDataGridViewTextBoxColumn.HeaderText = "nm_cidade";
            this.nmcidadeDataGridViewTextBoxColumn.Name = "nmcidadeDataGridViewTextBoxColumn";
            this.nmcidadeDataGridViewTextBoxColumn.Visible = false;
            // 
            // dsenderecoDataGridViewTextBoxColumn
            // 
            this.dsenderecoDataGridViewTextBoxColumn.DataPropertyName = "ds_endereco";
            this.dsenderecoDataGridViewTextBoxColumn.HeaderText = "ds_endereco";
            this.dsenderecoDataGridViewTextBoxColumn.Name = "dsenderecoDataGridViewTextBoxColumn";
            this.dsenderecoDataGridViewTextBoxColumn.Visible = false;
            // 
            // nmbairroDataGridViewTextBoxColumn
            // 
            this.nmbairroDataGridViewTextBoxColumn.DataPropertyName = "nm_bairro";
            this.nmbairroDataGridViewTextBoxColumn.HeaderText = "nm_bairro";
            this.nmbairroDataGridViewTextBoxColumn.Name = "nmbairroDataGridViewTextBoxColumn";
            this.nmbairroDataGridViewTextBoxColumn.Visible = false;
            // 
            // tbclienteBindingSource
            // 
            this.tbclienteBindingSource.DataMember = "tb_cliente";
            this.tbclienteBindingSource.DataSource = this.kafipeganyDataSet;
            // 
            // kafipeganyDataSet
            // 
            this.kafipeganyDataSet.DataSetName = "kafipeganyDataSet";
            this.kafipeganyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pnlFormularios
            // 
            this.pnlFormularios.BackColor = System.Drawing.Color.Transparent;
            this.pnlFormularios.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFormularios.BackgroundImage")));
            this.pnlFormularios.Controls.Add(this.txtcd);
            this.pnlFormularios.Controls.Add(this.txtCep);
            this.pnlFormularios.Controls.Add(this.label18);
            this.pnlFormularios.Controls.Add(this.label14);
            this.pnlFormularios.Controls.Add(this.txtBairro);
            this.pnlFormularios.Controls.Add(this.label15);
            this.pnlFormularios.Controls.Add(this.txtEndereco);
            this.pnlFormularios.Controls.Add(this.txtCidade);
            this.pnlFormularios.Controls.Add(this.txtEstado);
            this.pnlFormularios.Controls.Add(this.label16);
            this.pnlFormularios.Controls.Add(this.label17);
            this.pnlFormularios.Controls.Add(this.label11);
            this.pnlFormularios.Controls.Add(this.txtInscricaoEstadual);
            this.pnlFormularios.Controls.Add(this.txtCnpj);
            this.pnlFormularios.Controls.Add(this.txtPlaca);
            this.pnlFormularios.Controls.Add(this.txtTipoVeiculo);
            this.pnlFormularios.Controls.Add(this.txtNomeMarcaVeiculo);
            this.pnlFormularios.Controls.Add(this.pnlBotoes);
            this.pnlFormularios.Controls.Add(this.label13);
            this.pnlFormularios.Controls.Add(this.label12);
            this.pnlFormularios.Controls.Add(this.label10);
            this.pnlFormularios.Controls.Add(this.label9);
            this.pnlFormularios.Controls.Add(this.label8);
            this.pnlFormularios.Controls.Add(this.txtEstadoCivil);
            this.pnlFormularios.Controls.Add(this.txtEmail);
            this.pnlFormularios.Controls.Add(this.txtCelular);
            this.pnlFormularios.Controls.Add(this.txtTelefone);
            this.pnlFormularios.Controls.Add(this.label7);
            this.pnlFormularios.Controls.Add(this.label5);
            this.pnlFormularios.Controls.Add(this.label4);
            this.pnlFormularios.Controls.Add(this.label3);
            this.pnlFormularios.Controls.Add(this.txtDataNascimento);
            this.pnlFormularios.Controls.Add(this.label2);
            this.pnlFormularios.Controls.Add(this.label1);
            this.pnlFormularios.Controls.Add(this.label6);
            this.pnlFormularios.Controls.Add(this.txtCpf);
            this.pnlFormularios.Controls.Add(this.txtRg);
            this.pnlFormularios.Controls.Add(this.pnlPesquisa);
            this.pnlFormularios.Controls.Add(this.txtNome);
            this.pnlFormularios.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlFormularios.Location = new System.Drawing.Point(0, 0);
            this.pnlFormularios.Name = "pnlFormularios";
            this.pnlFormularios.Size = new System.Drawing.Size(480, 793);
            this.pnlFormularios.TabIndex = 0;
            // 
            // txtcd
            // 
            this.txtcd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtcd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcd.Enabled = false;
            this.txtcd.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtcd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtcd.Location = new System.Drawing.Point(254, 64);
            this.txtcd.Name = "txtcd";
            this.txtcd.Size = new System.Drawing.Size(76, 19);
            this.txtcd.TabIndex = 109;
            this.txtcd.Visible = false;
            // 
            // txtCep
            // 
            this.txtCep.Enabled = false;
            this.txtCep.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCep.Location = new System.Drawing.Point(333, 487);
            this.txtCep.Mask = "00000-000";
            this.txtCep.Name = "txtCep";
            this.txtCep.Size = new System.Drawing.Size(93, 26);
            this.txtCep.TabIndex = 108;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 14F);
            this.label18.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label18.Location = new System.Drawing.Point(277, 491);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 22);
            this.label18.TabIndex = 107;
            this.label18.Text = "CEP:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 14F);
            this.label14.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label14.Location = new System.Drawing.Point(27, 684);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 22);
            this.label14.TabIndex = 106;
            this.label14.Text = "Bairro:";
            // 
            // txtBairro
            // 
            this.txtBairro.Enabled = false;
            this.txtBairro.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtBairro.Location = new System.Drawing.Point(124, 681);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(200, 26);
            this.txtBairro.TabIndex = 105;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 14F);
            this.label15.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label15.Location = new System.Drawing.Point(26, 639);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 22);
            this.label15.TabIndex = 104;
            this.label15.Text = "Endereço:";
            // 
            // txtEndereco
            // 
            this.txtEndereco.Enabled = false;
            this.txtEndereco.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtEndereco.Location = new System.Drawing.Point(124, 635);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(234, 26);
            this.txtEndereco.TabIndex = 103;
            // 
            // txtCidade
            // 
            this.txtCidade.Enabled = false;
            this.txtCidade.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCidade.Location = new System.Drawing.Point(324, 585);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(147, 26);
            this.txtCidade.TabIndex = 102;
            // 
            // txtEstado
            // 
            this.txtEstado.Enabled = false;
            this.txtEstado.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtEstado.Location = new System.Drawing.Point(91, 585);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.Size = new System.Drawing.Size(147, 26);
            this.txtEstado.TabIndex = 101;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 14F);
            this.label16.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label16.Location = new System.Drawing.Point(20, 585);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(70, 22);
            this.label16.TabIndex = 100;
            this.label16.Text = "Estado:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 14F);
            this.label17.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label17.Location = new System.Drawing.Point(253, 585);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 22);
            this.label17.TabIndex = 99;
            this.label17.Text = "Cidade:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 14F);
            this.label11.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label11.Location = new System.Drawing.Point(21, 538);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(162, 22);
            this.label11.TabIndex = 98;
            this.label11.Text = "Inscrição Estadual:";
            // 
            // txtInscricaoEstadual
            // 
            this.txtInscricaoEstadual.Enabled = false;
            this.txtInscricaoEstadual.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtInscricaoEstadual.Location = new System.Drawing.Point(184, 538);
            this.txtInscricaoEstadual.Name = "txtInscricaoEstadual";
            this.txtInscricaoEstadual.Size = new System.Drawing.Size(141, 26);
            this.txtInscricaoEstadual.TabIndex = 97;
            // 
            // txtCnpj
            // 
            this.txtCnpj.Enabled = false;
            this.txtCnpj.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCnpj.Location = new System.Drawing.Point(83, 487);
            this.txtCnpj.Mask = "00,000,000/0000-00";
            this.txtCnpj.Name = "txtCnpj";
            this.txtCnpj.Size = new System.Drawing.Size(124, 26);
            this.txtCnpj.TabIndex = 96;
            // 
            // txtPlaca
            // 
            this.txtPlaca.Enabled = false;
            this.txtPlaca.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtPlaca.Location = new System.Drawing.Point(366, 437);
            this.txtPlaca.Name = "txtPlaca";
            this.txtPlaca.Size = new System.Drawing.Size(105, 26);
            this.txtPlaca.TabIndex = 95;
            // 
            // txtTipoVeiculo
            // 
            this.txtTipoVeiculo.Enabled = false;
            this.txtTipoVeiculo.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtTipoVeiculo.FormattingEnabled = true;
            this.txtTipoVeiculo.Items.AddRange(new object[] {
            "Automóvel",
            "Bicicleta",
            "Motocicleta"});
            this.txtTipoVeiculo.Location = new System.Drawing.Point(165, 436);
            this.txtTipoVeiculo.Name = "txtTipoVeiculo";
            this.txtTipoVeiculo.Size = new System.Drawing.Size(124, 27);
            this.txtTipoVeiculo.TabIndex = 94;
            // 
            // txtNomeMarcaVeiculo
            // 
            this.txtNomeMarcaVeiculo.Enabled = false;
            this.txtNomeMarcaVeiculo.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtNomeMarcaVeiculo.Location = new System.Drawing.Point(238, 394);
            this.txtNomeMarcaVeiculo.Name = "txtNomeMarcaVeiculo";
            this.txtNomeMarcaVeiculo.Size = new System.Drawing.Size(233, 26);
            this.txtNomeMarcaVeiculo.TabIndex = 93;
            // 
            // pnlBotoes
            // 
            this.pnlBotoes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlBotoes.Controls.Add(this.btnSair);
            this.pnlBotoes.Controls.Add(this.btnNovo);
            this.pnlBotoes.Controls.Add(this.btnSalvar);
            this.pnlBotoes.Controls.Add(this.btnExcluir);
            this.pnlBotoes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBotoes.Location = new System.Drawing.Point(0, 713);
            this.pnlBotoes.Name = "pnlBotoes";
            this.pnlBotoes.Size = new System.Drawing.Size(480, 80);
            this.pnlBotoes.TabIndex = 92;
            // 
            // btnSair
            // 
            this.btnSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSair.BackgroundImage")));
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.ForeColor = System.Drawing.Color.Transparent;
            this.btnSair.Location = new System.Drawing.Point(342, 14);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(51, 66);
            this.btnSair.TabIndex = 67;
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Location = new System.Drawing.Point(65, 6);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(72, 71);
            this.btnNovo.TabIndex = 66;
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalvar.BackgroundImage")));
            this.btnSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.ForeColor = System.Drawing.Color.Transparent;
            this.btnSalvar.Location = new System.Drawing.Point(163, 14);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(52, 61);
            this.btnSalvar.TabIndex = 64;
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExcluir.BackgroundImage")));
            this.btnExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Location = new System.Drawing.Point(257, 14);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(61, 61);
            this.btnExcluir.TabIndex = 65;
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 14F);
            this.label13.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label13.Location = new System.Drawing.Point(21, 491);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 22);
            this.label13.TabIndex = 91;
            this.label13.Text = "CNPJ:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 14F);
            this.label12.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label12.Location = new System.Drawing.Point(303, 441);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 22);
            this.label12.TabIndex = 89;
            this.label12.Text = "Placa:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 14F);
            this.label10.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label10.Location = new System.Drawing.Point(20, 398);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(212, 22);
            this.label10.TabIndex = 83;
            this.label10.Text = "Nome e Marca do veículo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 14F);
            this.label9.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label9.Location = new System.Drawing.Point(21, 441);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 22);
            this.label9.TabIndex = 82;
            this.label9.Text = "Tipo de Veículo:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 14F);
            this.label8.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label8.Location = new System.Drawing.Point(21, 352);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 22);
            this.label8.TabIndex = 81;
            this.label8.Text = "Estado Civil :";
            // 
            // txtEstadoCivil
            // 
            this.txtEstadoCivil.Enabled = false;
            this.txtEstadoCivil.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtEstadoCivil.FormattingEnabled = true;
            this.txtEstadoCivil.Items.AddRange(new object[] {
            "Casado(a)",
            "Solteiro(a)",
            "Divorciado(a)",
            "Viúvo(a)"});
            this.txtEstadoCivil.Location = new System.Drawing.Point(141, 352);
            this.txtEstadoCivil.Name = "txtEstadoCivil";
            this.txtEstadoCivil.Size = new System.Drawing.Size(124, 27);
            this.txtEstadoCivil.TabIndex = 80;
            // 
            // txtEmail
            // 
            this.txtEmail.Enabled = false;
            this.txtEmail.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtEmail.Location = new System.Drawing.Point(91, 296);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(276, 26);
            this.txtEmail.TabIndex = 79;
            // 
            // txtCelular
            // 
            this.txtCelular.Enabled = false;
            this.txtCelular.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCelular.Location = new System.Drawing.Point(342, 246);
            this.txtCelular.Mask = "(99)0000-00000";
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(129, 26);
            this.txtCelular.TabIndex = 78;
            // 
            // txtTelefone
            // 
            this.txtTelefone.Enabled = false;
            this.txtTelefone.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtTelefone.Location = new System.Drawing.Point(105, 246);
            this.txtTelefone.Mask = "(99) 0000-0000";
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(115, 26);
            this.txtTelefone.TabIndex = 77;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 14F);
            this.label7.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label7.Location = new System.Drawing.Point(18, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(175, 22);
            this.label7.TabIndex = 76;
            this.label7.Text = "Data de Nascimento:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 14F);
            this.label5.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label5.Location = new System.Drawing.Point(21, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 22);
            this.label5.TabIndex = 75;
            this.label5.Text = "Email:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 14F);
            this.label4.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label4.Location = new System.Drawing.Point(257, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 22);
            this.label4.TabIndex = 74;
            this.label4.Text = "Celular:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14F);
            this.label3.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label3.Location = new System.Drawing.Point(20, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 22);
            this.label3.TabIndex = 73;
            this.label3.Text = "Telefone:";
            // 
            // txtDataNascimento
            // 
            this.txtDataNascimento.CustomFormat = "yyyy/MM/dd";
            this.txtDataNascimento.Enabled = false;
            this.txtDataNascimento.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtDataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtDataNascimento.Location = new System.Drawing.Point(199, 190);
            this.txtDataNascimento.Name = "txtDataNascimento";
            this.txtDataNascimento.Size = new System.Drawing.Size(126, 26);
            this.txtDataNascimento.TabIndex = 72;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14F);
            this.label2.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label2.Location = new System.Drawing.Point(190, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 22);
            this.label2.TabIndex = 71;
            this.label2.Text = "CPF:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14F);
            this.label1.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label1.Location = new System.Drawing.Point(20, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 22);
            this.label1.TabIndex = 70;
            this.label1.Text = "RG:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 14F);
            this.label6.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label6.Location = new System.Drawing.Point(20, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 22);
            this.label6.TabIndex = 69;
            this.label6.Text = "Nome:";
            // 
            // txtCpf
            // 
            this.txtCpf.Enabled = false;
            this.txtCpf.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCpf.Location = new System.Drawing.Point(242, 139);
            this.txtCpf.Mask = "000,000,000-00";
            this.txtCpf.Name = "txtCpf";
            this.txtCpf.Size = new System.Drawing.Size(125, 26);
            this.txtCpf.TabIndex = 64;
            // 
            // txtRg
            // 
            this.txtRg.Enabled = false;
            this.txtRg.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtRg.Location = new System.Drawing.Point(65, 143);
            this.txtRg.Mask = "00,000,000-0";
            this.txtRg.Name = "txtRg";
            this.txtRg.Size = new System.Drawing.Size(106, 26);
            this.txtRg.TabIndex = 63;
            // 
            // pnlPesquisa
            // 
            this.pnlPesquisa.BackColor = System.Drawing.Color.Gray;
            this.pnlPesquisa.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlPesquisa.Location = new System.Drawing.Point(0, 0);
            this.pnlPesquisa.Name = "pnlPesquisa";
            this.pnlPesquisa.Size = new System.Drawing.Size(480, 61);
            this.pnlPesquisa.TabIndex = 62;
            // 
            // txtNome
            // 
            this.txtNome.Enabled = false;
            this.txtNome.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtNome.Location = new System.Drawing.Point(105, 89);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(262, 26);
            this.txtNome.TabIndex = 61;
            // 
            // tbclienteBindingSource1
            // 
            this.tbclienteBindingSource1.DataMember = "tb_cliente";
            this.tbclienteBindingSource1.DataSource = this.kafipeganyDataSet;
            // 
            // tb_clienteTableAdapter
            // 
            this.tb_clienteTableAdapter.ClearBeforeFill = true;
            // 
            // frmCadastroHospede
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1869, 971);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCadastroHospede";
            this.Text = "frmCadastroHospede";
            this.Load += new System.EventHandler(this.frmCadastroHospede_Load);
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridHospede)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).EndInit();
            this.pnlFormularios.ResumeLayout(false);
            this.pnlFormularios.PerformLayout();
            this.pnlBotoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnlFormularios;
        private System.Windows.Forms.MaskedTextBox txtCep;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.TextBox txtEstado;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtInscricaoEstadual;
        private System.Windows.Forms.MaskedTextBox txtCnpj;
        private System.Windows.Forms.TextBox txtPlaca;
        private System.Windows.Forms.ComboBox txtTipoVeiculo;
        private System.Windows.Forms.TextBox txtNomeMarcaVeiculo;
        private System.Windows.Forms.Panel pnlBotoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox txtEstadoCivil;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.MaskedTextBox txtCelular;
        private System.Windows.Forms.MaskedTextBox txtTelefone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker txtDataNascimento;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox txtCpf;
        private System.Windows.Forms.MaskedTextBox txtRg;
        private System.Windows.Forms.Panel pnlPesquisa;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtcd;
        private System.Windows.Forms.Panel panel1;
        private kafipeganyDataSet kafipeganyDataSet;
        private System.Windows.Forms.BindingSource tbclienteBindingSource;
        private kafipeganyDataSetTableAdapters.tb_clienteTableAdapter tb_clienteTableAdapter;
        private System.Windows.Forms.BindingSource tbclienteBindingSource1;
        private System.Windows.Forms.DataGridView GridHospede;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdclienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmclienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdrgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdcpfDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtnascimentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dstelefoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dscelularDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsestadocivilDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsveiculoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dstipoVeiculoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdCnpjDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdplacaVeiculoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdCepDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmestadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdInscricaoEstadualDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmcidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsenderecoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmbairroDataGridViewTextBoxColumn;
    }
}