﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.Dal;
using Kafipegany.Entidades;
namespace Kafipegany.Model
{
    public class HospedeModelcs
    {
        AcessoBanco bd;

        public void InserirCliente(tb_hospede tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_cliente.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_cliente(nm_cliente,cd_rg,cd_cpf,dt_nascimento,ds_telefone,ds_celular,ds_email,ds_estadocivil,ds_veiculo,ds_tipoVeiculo,cd_Cnpj,cd_InscricaoEstadual,cd_placaVeiculo,cd_Cep,nm_estado,nm_cidade,ds_endereco,nm_bairro) VALUES('" + tb.Nm_cliente + "','" + tb.Cd_rg + "','" + tb.Cd_cpf + "','" + tb.Dt_nascimento + "','" + tb.Ds_telefone + "','" + tb.Ds_celular + "','" + tb.Ds_email + "','" + tb.Ds_estadocivil + "','" + tb.Ds_veiculo + "','" + tb.Ds_tipoVeiculo + "','" + tb.Cd_cnpj + "','" + tb.Cd_inscricaoEstadual + "','" + tb.Cd_placaVeiculo + "','" + tb.Cd_cep + "','" + tb.Nm_estado + "','" + tb.Nm_cidade + "','" + tb.Ds_endereco + "','" + tb.Nm_bairro + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Cliente: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void AtualizarCliente(tb_hospede tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_cliente.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela
                string comando = "UPDATE tb_cliente set nm_cliente = '" + tb.Nm_cliente + "',cd_rg='" + tb.Cd_rg + "', cd_cpf='" + tb.Cd_cpf + "', dt_nascimento='" + tb.Dt_nascimento + "', ds_telefone='" + tb.Ds_telefone + "', ds_celular='" + tb.Ds_celular + "', ds_email='" + tb.Ds_email + "', ds_estadocivil='" + tb.Ds_estadocivil + "', ds_veiculo='" + tb.Ds_veiculo + "', ds_tipoVeiculo='" + tb.Ds_tipoVeiculo + "', cd_Cnpj='" + tb.Cd_cnpj + "', cd_InscricaoEstadual='" + tb.Cd_inscricaoEstadual + "', cd_placaVeiculo='" + tb.Cd_placaVeiculo + "', cd_Cep='" + tb.Cd_cep + "', nm_cidade='" + tb.Nm_cidade + "', nm_estado='" + tb.Nm_estado + "', ds_endereco='" + tb.Ds_endereco + "', nm_bairro='" + tb.Nm_bairro + "' where cd_cliente =" + tb.Cd_cliente;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o usuário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public DataTable SelecionaTodosClientes()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBanco();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_cliente, nm_cliente,cd_rg,cd_cpf,dt_nascimento,ds_telefone,ds_celular,ds_email,ds_estadocivil,ds_veiculo,ds_tipoVeiculo,cd_Cnpj,cd_InscricaoEstadual,cd_placaVeiculo,cd_Cep,nm_estado,nm_cidade,ds_endereco,nm_bairro from tb_cliente");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todos os Clientes: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void ExcluirCliente(string cd_cliente)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_cliente where cd_cliente = " + cd_cliente;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir o cliente: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void PesquisarClienteNome(string nm_nome)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();
                string comando = "SELECT tb_cliente where nm_cliente = " + nm_nome;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
        public void PesquisarClienteCpf(string nm_cpf)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();
                string comando = "SELECT tb_cliente where cd_cpf = " + nm_cpf;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
        public void PesquisarClienteCnpj(string cnpj)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();
                string comando = "SELECT tb_cliente where cd_Cnpj = " + cnpj;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
    }
}
