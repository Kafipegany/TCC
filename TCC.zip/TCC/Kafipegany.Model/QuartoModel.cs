﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.Dal;
using Kafipegany.Entidades;
namespace Kafipegany.Model
{
   public class QuartoModel
    {
        AcessoBanco bd;

        public void InserirQuarto(tb_quarto tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_quarto.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_quarto(nm_quarto,nr_capacidade, ds_quarto) VALUES('" + tb.Nm_quarto + "','" + tb.Nr_capacidade + "','" + tb.Ds_quato + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o quarto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void AtualizarQuarto(tb_quarto tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_quarto.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela
                string comando = "UPDATE tb_cliente set nm_quarto = '" + tb.Nm_quarto + "',nr_capacidade='" + tb.Nr_capacidade + "',  ds_quarto='" + tb.Ds_quato+"', id_reserva='"+ tb.Id_reserva;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o quarto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public DataTable SelecionaTodosQuartos()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBanco();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_quarto, nm_quarto,nr_capacidade, ds_quarto from tb_quarto");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todos os quartos: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void ExcluirQuarto(string cd_quarto)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_quarto where cd_quarto = " + cd_quarto;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir o quarto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
    }
}
