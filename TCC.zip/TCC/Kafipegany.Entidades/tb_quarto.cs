﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_quarto
    {
        private int cd_quarto;
        private string nm_quarto;
        private string nr_capacidade;
        private string ds_quato;
        private string id_reserva;

        // get set (encapsulamento)

        public int Cd_quarto { get => cd_quarto; set => cd_quarto = value; }
        public string Nm_quarto { get => nm_quarto; set => nm_quarto = value; }
        public string Nr_capacidade { get => nr_capacidade; set => nr_capacidade = value; }
        public string Ds_quato { get => ds_quato; set => ds_quato = value; }
        public string Id_reserva { get => id_reserva; set => id_reserva = value; }
    }
}
