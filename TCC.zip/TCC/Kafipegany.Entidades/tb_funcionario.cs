﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_funcionario
    {
        private int cd_funcionario;
        private string nm_funcionario;
        private string ds_cargo;
        private string dt_nascimento;
        private string cd_rg;
        private string cd_cpf;
        private string ds_telefone;
        private string ds_celular;
        private string cd_cep;
        private string nm_estado;
        private string nm_cidade;
        private string ds_endereco;
        private string nm_bairro;

        public int Cd_funcionario { get => cd_funcionario; set => cd_funcionario = value; }
        public string Nm_funcionario { get => nm_funcionario; set => nm_funcionario = value; }
        public string Ds_cargo { get => ds_cargo; set => ds_cargo = value; }
        public string Dt_nascimento { get => dt_nascimento; set => dt_nascimento = value;
        }
        public string Cd_rg { get => cd_rg; set => cd_rg = value; }
        public string Cd_cpf { get => cd_cpf; set => cd_cpf = value; }
        public string Ds_telefone { get => ds_telefone; set => ds_telefone = value; }
        public string Ds_celular { get => ds_celular; set => ds_celular = value; }
        public string Cd_cep { get => cd_cep; set => cd_cep = value; }
        public string Nm_estado { get => nm_estado; set => nm_estado = value; }
        public string Nm_cidade { get => nm_cidade; set => nm_cidade = value; }
        public string Ds_endereco { get => ds_endereco; set => ds_endereco = value; }
        public string Nm_bairro { get => nm_bairro; set => nm_bairro = value; }
    }
}
