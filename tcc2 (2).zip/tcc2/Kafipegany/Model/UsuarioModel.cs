﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.Dal;
using Kafipegany.Entidades;
namespace Kafipegany.Model
{
    public class UsuarioModel
    {
        AcessoBanco bd;
        public bool tem;
        public string mensagem = "";


        public void Inserir(tb_usuario tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Usuario.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_usuario(nm_username,nm_Cargo,cd_senha) VALUES('" + tb.Usuario + "','" + tb.Cargo + "','" + tb.Senha + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Usuário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void Atualizar(tb_usuario tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Usuario.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "UPDATE tb_usuario set nm_username = '" + tb.Usuario + "',nm_Cargo='" + tb.Cargo + "', cd_senha='" + tb.Senha + "' where cd_usuario =" + tb.Id;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o usuário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public DataTable SelecionaTodosUsuarios()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBanco();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_usuario, nm_username,nm_Cargo,cd_senha from tb_usuario");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todos os Usuarios: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void Excluir(string id_usuario)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_usuario where cd_usuario = " + id_usuario;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir o usuário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void Pesquisar(string nm_nome)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();
                string comando = "SELECT tb_usuario where nm_usuario = " + nm_nome;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
    }
}
