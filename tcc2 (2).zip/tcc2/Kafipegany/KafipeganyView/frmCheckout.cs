﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyView
{
    public partial class frmCheckout : Form
    {
        double total = 0;
        double consumo = 0;
        double diaria = 0;
        public frmCheckout()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            HabilitarCampos();
            btnSalvar.Enabled = true;
        }
        private void HabilitarCampos()
        {
            cbQuarto.Enabled = true;
            
           
            comboBox1.Enabled = true;
        }

        private void LimparCampos()
        {

            cbQuarto.Text = "";
            txtConsumo.Text = "";
            txtDiaria.Text = "";
            txtTotal.Text = "";
            comboBox1.Text = "";
        }

        private void Desabilitar()
        {
            cbQuarto.Enabled = false;
            
            comboBox1.Enabled = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
           
            MessageBox.Show("O CheckOut foi Realizado com sucesso!", "Finalizado com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void cbQuarto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbQuarto.Text == "1")
            {
                diaria = 100.00;
                txtDiaria.Text = diaria.ToString();
            }
            else if (cbQuarto.Text == "2")
            {
                diaria = 120.00;
                txtDiaria.Text = diaria.ToString();
            }
            else if(cbQuarto.Text == "3")
            {
                diaria = 80.00;
                txtDiaria.Text = diaria.ToString();
            }
            else if (cbQuarto.Text == "4")
            {
                diaria = 180.00;
                txtDiaria.Text = diaria.ToString();
            }
            else if (cbQuarto.Text == "5")
            {
                diaria = 220.00;
                txtDiaria.Text = diaria.ToString();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text== "Kauan")
            {
                consumo = 50;
                txtConsumo.Text = consumo.ToString();
            }
            else if (comboBox1.Text == "Henrique")
            {
                consumo = 75;
                txtConsumo.Text = consumo.ToString();
            }
            else if (comboBox1.Text == "Emilio")
            {
                consumo = 35;
                txtConsumo.Text = consumo.ToString();
            }
            else if (comboBox1.Text == "Lara")
            {
                consumo = 130;
                txtConsumo.Text = consumo.ToString();
            }
            else if (comboBox1.Text == "Camila")
            {
                consumo = 78;
                txtConsumo.Text = consumo.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            consumo =Convert.ToDouble(txtConsumo.Text);
       
            diaria = Convert.ToDouble(txtDiaria.Text);
            total = diaria + consumo;
            txtTotal.Text =total.ToString();
            
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
