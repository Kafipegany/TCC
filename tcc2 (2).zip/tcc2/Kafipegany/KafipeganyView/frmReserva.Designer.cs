﻿namespace KafipeganyView
{
    partial class frmReserva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReserva));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.btnIconeMinimizar = new System.Windows.Forms.PictureBox();
            this.btnIconeEncerrar = new System.Windows.Forms.PictureBox();
            this.txtcd = new System.Windows.Forms.TextBox();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.GridOcupacoes = new System.Windows.Forms.DataGridView();
            this.txtDias = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.lbl31 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.lbl28 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.lbl30 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.lbl29 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lbl27 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.lbl26 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.lbl25 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.lbl24 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lbl23 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.lbl22 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lbl21 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lbl20 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.lbl19 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.lbl18 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lbl17 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lbl16 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.lbl15 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbl14 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbl13 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lbl12 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lbl11 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.lbl10 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lbl9 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lbl8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbl7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbl5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl1 = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbAno = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbMes = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbQuarto = new System.Windows.Forms.ComboBox();
            this.pnlTopo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridOcupacoes)).BeginInit();
            this.panel29.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.Black;
            this.pnlTopo.Controls.Add(this.btnIconeMinimizar);
            this.pnlTopo.Controls.Add(this.btnIconeEncerrar);
            this.pnlTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(817, 40);
            this.pnlTopo.TabIndex = 7;
            // 
            // btnIconeMinimizar
            // 
            this.btnIconeMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeMinimizar.Image")));
            this.btnIconeMinimizar.Location = new System.Drawing.Point(731, 0);
            this.btnIconeMinimizar.Name = "btnIconeMinimizar";
            this.btnIconeMinimizar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeMinimizar.TabIndex = 2;
            this.btnIconeMinimizar.TabStop = false;
            this.btnIconeMinimizar.Click += new System.EventHandler(this.btnIconeMinimizar_Click);
            // 
            // btnIconeEncerrar
            // 
            this.btnIconeEncerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeEncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeEncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeEncerrar.Image")));
            this.btnIconeEncerrar.Location = new System.Drawing.Point(777, 0);
            this.btnIconeEncerrar.Name = "btnIconeEncerrar";
            this.btnIconeEncerrar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeEncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeEncerrar.TabIndex = 1;
            this.btnIconeEncerrar.TabStop = false;
            this.btnIconeEncerrar.Click += new System.EventHandler(this.btnIconeEncerrar_Click);
            // 
            // txtcd
            // 
            this.txtcd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtcd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcd.Enabled = false;
            this.txtcd.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtcd.Location = new System.Drawing.Point(36, 90);
            this.txtcd.Name = "txtcd";
            this.txtcd.Size = new System.Drawing.Size(76, 19);
            this.txtcd.TabIndex = 189;
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Location = new System.Drawing.Point(461, 519);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(72, 71);
            this.btnNovo.TabIndex = 188;
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalvar.BackgroundImage")));
            this.btnSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.ForeColor = System.Drawing.Color.Transparent;
            this.btnSalvar.Location = new System.Drawing.Point(567, 529);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(52, 61);
            this.btnSalvar.TabIndex = 187;
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // GridOcupacoes
            // 
            this.GridOcupacoes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridOcupacoes.Location = new System.Drawing.Point(358, 314);
            this.GridOcupacoes.Name = "GridOcupacoes";
            this.GridOcupacoes.Size = new System.Drawing.Size(447, 199);
            this.GridOcupacoes.TabIndex = 186;
            // 
            // txtDias
            // 
            this.txtDias.Enabled = false;
            this.txtDias.Location = new System.Drawing.Point(619, 147);
            this.txtDias.Name = "txtDias";
            this.txtDias.Size = new System.Drawing.Size(79, 20);
            this.txtDias.TabIndex = 185;
            this.txtDias.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 14F);
            this.label7.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label7.Location = new System.Drawing.Point(563, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 22);
            this.label7.TabIndex = 184;
            this.label7.Text = "Dias:";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.Transparent;
            this.panel29.Controls.Add(this.lbl31);
            this.panel29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel29.Location = new System.Drawing.Point(112, 457);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(35, 35);
            this.panel29.TabIndex = 183;
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(4, 8);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(27, 19);
            this.lbl31.TabIndex = 107;
            this.lbl31.Text = "31";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Transparent;
            this.panel22.Controls.Add(this.lbl28);
            this.panel22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel22.Location = new System.Drawing.Point(276, 416);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(35, 35);
            this.panel22.TabIndex = 180;
            // 
            // lbl28
            // 
            this.lbl28.AutoSize = true;
            this.lbl28.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl28.ForeColor = System.Drawing.Color.White;
            this.lbl28.Location = new System.Drawing.Point(4, 8);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(27, 19);
            this.lbl28.TabIndex = 107;
            this.lbl28.Text = "28";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Transparent;
            this.panel30.Controls.Add(this.lbl30);
            this.panel30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel30.Location = new System.Drawing.Point(69, 457);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(35, 35);
            this.panel30.TabIndex = 182;
            // 
            // lbl30
            // 
            this.lbl30.AutoSize = true;
            this.lbl30.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl30.ForeColor = System.Drawing.Color.White;
            this.lbl30.Location = new System.Drawing.Point(4, 8);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(27, 19);
            this.lbl30.TabIndex = 107;
            this.lbl30.Text = "30";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Transparent;
            this.panel31.Controls.Add(this.lbl29);
            this.panel31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel31.Location = new System.Drawing.Point(28, 457);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(35, 35);
            this.panel31.TabIndex = 181;
            // 
            // lbl29
            // 
            this.lbl29.AutoSize = true;
            this.lbl29.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl29.ForeColor = System.Drawing.Color.White;
            this.lbl29.Location = new System.Drawing.Point(4, 8);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(27, 19);
            this.lbl29.TabIndex = 107;
            this.lbl29.Text = "29";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Transparent;
            this.panel23.Controls.Add(this.lbl27);
            this.panel23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel23.Location = new System.Drawing.Point(233, 416);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(35, 35);
            this.panel23.TabIndex = 179;
            // 
            // lbl27
            // 
            this.lbl27.AutoSize = true;
            this.lbl27.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl27.ForeColor = System.Drawing.Color.White;
            this.lbl27.Location = new System.Drawing.Point(4, 8);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(27, 19);
            this.lbl27.TabIndex = 107;
            this.lbl27.Text = "27";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Transparent;
            this.panel24.Controls.Add(this.lbl26);
            this.panel24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel24.Location = new System.Drawing.Point(192, 416);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(35, 35);
            this.panel24.TabIndex = 175;
            // 
            // lbl26
            // 
            this.lbl26.AutoSize = true;
            this.lbl26.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl26.ForeColor = System.Drawing.Color.White;
            this.lbl26.Location = new System.Drawing.Point(4, 8);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(27, 19);
            this.lbl26.TabIndex = 107;
            this.lbl26.Text = "26";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Transparent;
            this.panel25.Controls.Add(this.lbl25);
            this.panel25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel25.Location = new System.Drawing.Point(151, 416);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(35, 35);
            this.panel25.TabIndex = 176;
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl25.ForeColor = System.Drawing.Color.White;
            this.lbl25.Location = new System.Drawing.Point(4, 8);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(27, 19);
            this.lbl25.TabIndex = 107;
            this.lbl25.Text = "25";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Transparent;
            this.panel26.Controls.Add(this.lbl24);
            this.panel26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel26.Location = new System.Drawing.Point(110, 416);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(35, 35);
            this.panel26.TabIndex = 177;
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl24.ForeColor = System.Drawing.Color.White;
            this.lbl24.Location = new System.Drawing.Point(4, 8);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(27, 19);
            this.lbl24.TabIndex = 107;
            this.lbl24.Text = "24";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Transparent;
            this.panel27.Controls.Add(this.lbl23);
            this.panel27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel27.Location = new System.Drawing.Point(69, 416);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(35, 35);
            this.panel27.TabIndex = 178;
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(4, 8);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(27, 19);
            this.lbl23.TabIndex = 107;
            this.lbl23.Text = "23";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Transparent;
            this.panel28.Controls.Add(this.lbl22);
            this.panel28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel28.Location = new System.Drawing.Point(28, 416);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(35, 35);
            this.panel28.TabIndex = 174;
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(4, 8);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(27, 19);
            this.lbl22.TabIndex = 107;
            this.lbl22.Text = "22";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Transparent;
            this.panel15.Controls.Add(this.lbl21);
            this.panel15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel15.Location = new System.Drawing.Point(276, 375);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(35, 35);
            this.panel15.TabIndex = 173;
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(4, 8);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(27, 19);
            this.lbl21.TabIndex = 107;
            this.lbl21.Text = "21";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Transparent;
            this.panel16.Controls.Add(this.lbl20);
            this.panel16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel16.Location = new System.Drawing.Point(233, 375);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(35, 35);
            this.panel16.TabIndex = 172;
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl20.ForeColor = System.Drawing.Color.White;
            this.lbl20.Location = new System.Drawing.Point(4, 8);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(27, 19);
            this.lbl20.TabIndex = 107;
            this.lbl20.Text = "20";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Transparent;
            this.panel17.Controls.Add(this.lbl19);
            this.panel17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel17.Location = new System.Drawing.Point(192, 375);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(35, 35);
            this.panel17.TabIndex = 168;
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl19.ForeColor = System.Drawing.Color.White;
            this.lbl19.Location = new System.Drawing.Point(4, 8);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(27, 19);
            this.lbl19.TabIndex = 107;
            this.lbl19.Text = "19";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Transparent;
            this.panel18.Controls.Add(this.lbl18);
            this.panel18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel18.Location = new System.Drawing.Point(151, 375);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(35, 35);
            this.panel18.TabIndex = 169;
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl18.ForeColor = System.Drawing.Color.White;
            this.lbl18.Location = new System.Drawing.Point(4, 8);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(27, 19);
            this.lbl18.TabIndex = 107;
            this.lbl18.Text = "18";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Transparent;
            this.panel19.Controls.Add(this.lbl17);
            this.panel19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel19.Location = new System.Drawing.Point(110, 375);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(35, 35);
            this.panel19.TabIndex = 170;
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl17.ForeColor = System.Drawing.Color.White;
            this.lbl17.Location = new System.Drawing.Point(4, 8);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(27, 19);
            this.lbl17.TabIndex = 107;
            this.lbl17.Text = "17";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Transparent;
            this.panel20.Controls.Add(this.lbl16);
            this.panel20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel20.Location = new System.Drawing.Point(69, 375);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(35, 35);
            this.panel20.TabIndex = 171;
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl16.ForeColor = System.Drawing.Color.White;
            this.lbl16.Location = new System.Drawing.Point(4, 8);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(27, 19);
            this.lbl16.TabIndex = 107;
            this.lbl16.Text = "16";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Transparent;
            this.panel21.Controls.Add(this.lbl15);
            this.panel21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel21.Location = new System.Drawing.Point(28, 375);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(35, 35);
            this.panel21.TabIndex = 167;
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl15.ForeColor = System.Drawing.Color.White;
            this.lbl15.Location = new System.Drawing.Point(4, 8);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(27, 19);
            this.lbl15.TabIndex = 107;
            this.lbl15.Text = "15";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.lbl14);
            this.panel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel8.Location = new System.Drawing.Point(276, 334);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(35, 35);
            this.panel8.TabIndex = 166;
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl14.ForeColor = System.Drawing.Color.White;
            this.lbl14.Location = new System.Drawing.Point(4, 8);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(27, 19);
            this.lbl14.TabIndex = 107;
            this.lbl14.Text = "14";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(this.lbl13);
            this.panel9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel9.Location = new System.Drawing.Point(233, 334);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(35, 35);
            this.panel9.TabIndex = 165;
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(4, 8);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(27, 19);
            this.lbl13.TabIndex = 107;
            this.lbl13.Text = "13";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Controls.Add(this.lbl12);
            this.panel10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel10.Location = new System.Drawing.Point(192, 334);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(35, 35);
            this.panel10.TabIndex = 161;
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(4, 8);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(27, 19);
            this.lbl12.TabIndex = 107;
            this.lbl12.Text = "12";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Transparent;
            this.panel11.Controls.Add(this.lbl11);
            this.panel11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel11.Location = new System.Drawing.Point(151, 334);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(35, 35);
            this.panel11.TabIndex = 162;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(4, 8);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(27, 19);
            this.lbl11.TabIndex = 107;
            this.lbl11.Text = "11";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Transparent;
            this.panel12.Controls.Add(this.lbl10);
            this.panel12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel12.Location = new System.Drawing.Point(110, 334);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(35, 35);
            this.panel12.TabIndex = 163;
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl10.ForeColor = System.Drawing.Color.White;
            this.lbl10.Location = new System.Drawing.Point(4, 8);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(27, 19);
            this.lbl10.TabIndex = 107;
            this.lbl10.Text = "10";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Transparent;
            this.panel13.Controls.Add(this.lbl9);
            this.panel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel13.Location = new System.Drawing.Point(69, 334);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(35, 35);
            this.panel13.TabIndex = 164;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl9.ForeColor = System.Drawing.Color.White;
            this.lbl9.Location = new System.Drawing.Point(4, 8);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(27, 19);
            this.lbl9.TabIndex = 107;
            this.lbl9.Text = "09";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Transparent;
            this.panel14.Controls.Add(this.lbl8);
            this.panel14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel14.Location = new System.Drawing.Point(28, 334);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(35, 35);
            this.panel14.TabIndex = 160;
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl8.ForeColor = System.Drawing.Color.White;
            this.lbl8.Location = new System.Drawing.Point(4, 8);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(27, 19);
            this.lbl8.TabIndex = 107;
            this.lbl8.Text = "08";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.lbl7);
            this.panel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel7.Location = new System.Drawing.Point(276, 293);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(35, 35);
            this.panel7.TabIndex = 159;
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl7.ForeColor = System.Drawing.Color.White;
            this.lbl7.Location = new System.Drawing.Point(4, 8);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(27, 19);
            this.lbl7.TabIndex = 107;
            this.lbl7.Text = "07";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.lbl6);
            this.panel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel6.Location = new System.Drawing.Point(233, 293);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(35, 35);
            this.panel6.TabIndex = 158;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl6.ForeColor = System.Drawing.Color.White;
            this.lbl6.Location = new System.Drawing.Point(4, 8);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(27, 19);
            this.lbl6.TabIndex = 107;
            this.lbl6.Text = "06";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.lbl5);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(192, 293);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(35, 35);
            this.panel5.TabIndex = 156;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl5.ForeColor = System.Drawing.Color.White;
            this.lbl5.Location = new System.Drawing.Point(4, 8);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(27, 19);
            this.lbl5.TabIndex = 107;
            this.lbl5.Text = "05";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.lbl4);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(151, 293);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(35, 35);
            this.panel4.TabIndex = 155;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl4.ForeColor = System.Drawing.Color.White;
            this.lbl4.Location = new System.Drawing.Point(4, 8);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(27, 19);
            this.lbl4.TabIndex = 107;
            this.lbl4.Text = "04";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.lbl3);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(110, 293);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(35, 35);
            this.panel3.TabIndex = 154;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl3.ForeColor = System.Drawing.Color.White;
            this.lbl3.Location = new System.Drawing.Point(4, 8);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(27, 19);
            this.lbl3.TabIndex = 107;
            this.lbl3.Text = "03";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.lbl2);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(69, 293);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(35, 35);
            this.panel2.TabIndex = 157;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl2.ForeColor = System.Drawing.Color.White;
            this.lbl2.Location = new System.Drawing.Point(4, 8);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(27, 19);
            this.lbl2.TabIndex = 107;
            this.lbl2.Text = "02";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(28, 293);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(35, 35);
            this.panel1.TabIndex = 153;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Cambria", 12F);
            this.lbl1.ForeColor = System.Drawing.Color.White;
            this.lbl1.Location = new System.Drawing.Point(4, 8);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(27, 19);
            this.lbl1.TabIndex = 107;
            this.lbl1.Text = "01";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Enabled = false;
            this.txtTelefone.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtTelefone.Location = new System.Drawing.Point(413, 200);
            this.txtTelefone.Mask = "(99) 0000-0000";
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(115, 26);
            this.txtTelefone.TabIndex = 152;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 14F);
            this.label5.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label5.Location = new System.Drawing.Point(324, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 22);
            this.label5.TabIndex = 151;
            this.label5.Text = "Telefone:";
            // 
            // txtNome
            // 
            this.txtNome.Enabled = false;
            this.txtNome.Location = new System.Drawing.Point(81, 204);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(230, 20);
            this.txtNome.TabIndex = 150;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 14F);
            this.label4.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label4.Location = new System.Drawing.Point(12, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 22);
            this.label4.TabIndex = 149;
            this.label4.Text = "Nome:";
            // 
            // txtValor
            // 
            this.txtValor.Enabled = false;
            this.txtValor.Location = new System.Drawing.Point(678, 204);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(79, 20);
            this.txtValor.TabIndex = 148;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14F);
            this.label3.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label3.Location = new System.Drawing.Point(562, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 22);
            this.label3.TabIndex = 147;
            this.label3.Text = "Valor Diária:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14F);
            this.label2.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label2.Location = new System.Drawing.Point(371, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 22);
            this.label2.TabIndex = 146;
            this.label2.Text = "Ano:";
            // 
            // cbAno
            // 
            this.cbAno.Enabled = false;
            this.cbAno.FormattingEnabled = true;
            this.cbAno.Items.AddRange(new object[] {
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2026",
            "2027",
            "2028",
            "2029",
            "2030",
            "2031",
            "2032",
            "2033",
            "2034",
            "2035",
            "2036",
            "2037",
            "2038",
            "2039",
            "2040",
            "2041",
            "2042",
            "2043",
            "2044",
            "2045",
            "2046",
            "2047",
            "2048",
            "2049",
            "2050"});
            this.cbAno.Location = new System.Drawing.Point(425, 143);
            this.cbAno.Name = "cbAno";
            this.cbAno.Size = new System.Drawing.Size(121, 21);
            this.cbAno.TabIndex = 145;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14F);
            this.label1.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label1.Location = new System.Drawing.Point(171, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 22);
            this.label1.TabIndex = 144;
            this.label1.Text = "Mês:";
            // 
            // cbMes
            // 
            this.cbMes.Enabled = false;
            this.cbMes.FormattingEnabled = true;
            this.cbMes.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cbMes.Location = new System.Drawing.Point(225, 143);
            this.cbMes.Name = "cbMes";
            this.cbMes.Size = new System.Drawing.Size(121, 21);
            this.cbMes.TabIndex = 143;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 14F);
            this.label6.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label6.Location = new System.Drawing.Point(12, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 22);
            this.label6.TabIndex = 142;
            this.label6.Text = "Quarto:";
            // 
            // cbQuarto
            // 
            this.cbQuarto.DisplayMember = "nm_quarto";
            this.cbQuarto.Enabled = false;
            this.cbQuarto.FormattingEnabled = true;
            this.cbQuarto.Location = new System.Drawing.Point(89, 143);
            this.cbQuarto.Name = "cbQuarto";
            this.cbQuarto.Size = new System.Drawing.Size(45, 21);
            this.cbQuarto.TabIndex = 141;
            // 
            // frmReserva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(817, 681);
            this.Controls.Add(this.txtcd);
            this.Controls.Add(this.btnNovo);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.GridOcupacoes);
            this.Controls.Add(this.txtDias);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel29);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel30);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.panel28);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbAno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMes);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbQuarto);
            this.Controls.Add(this.pnlTopo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmReserva";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmReserva";
            this.pnlTopo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridOcupacoes)).EndInit();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.PictureBox btnIconeMinimizar;
        private System.Windows.Forms.PictureBox btnIconeEncerrar;
        private System.Windows.Forms.TextBox txtcd;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.DataGridView GridOcupacoes;
        private System.Windows.Forms.TextBox txtDias;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.MaskedTextBox txtTelefone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbAno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbMes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbQuarto;
    }
}