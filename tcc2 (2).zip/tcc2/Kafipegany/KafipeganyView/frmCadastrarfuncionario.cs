﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Model;
namespace KafipeganyView
{
    public partial class frmCadastrarfuncionario : Form
    {
        FuncionarioModel model = new FuncionarioModel();
        tb_funcionario tb = new tb_funcionario();
        public frmCadastrarfuncionario()
        {
            InitializeComponent();
        }
        private void CarregarGrid()
        {
            GridFuncionario.DataSource = model.SelecionaTodosFuncionarios();
        }
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            HabilitarCampos();
            txtNome.Focus();
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilitar();
            tb.Nm_funcionario = txtNome.Text;
            tb.Cd_rg = txtRg.Text;
            tb.Cd_cpf = txtCpf.Text;
            tb.Dt_nascimento = txtDataNascimento.Text;
            tb.Ds_telefone = txtTelefone.Text;
            tb.Ds_celular = txtCelular.Text;
            tb.Cd_cep = txtCep.Text;
            tb.Ds_cargo = txtCargo.Text;
            tb.Nm_estado = txtEstado.Text;
            tb.Nm_cidade = txtCidade.Text;
            tb.Ds_endereco = txtEndereco.Text;
            tb.Nm_bairro = txtBairro.Text;

            if (txtNome.Text == "" && txtRg.Text == "" && txtCpf.Text == "" && txtDataNascimento.Text == "" && txtTelefone.Text == "" && txtCelular.Text == "" && txtCep.Text == "" &&
                txtCargo.Text == "" && txtEstado.Text == "" && txtCidade.Text == "" && txtEndereco.Text == "" && txtBairro.Text == "")
            {
                MessageBox.Show("Preencha os campos e tente novamente!", "Erro ao Inserir Funcionario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCampos();
            }
            else
            {
                if (txtNome.Text != "")
                {
                    if (txtRg.Text != "")
                    {
                        if (txtCpf.Text != "")
                        {
                            if (txtDataNascimento.Text != "")
                            {
                                txtDataNascimento.Format = DateTimePickerFormat.Custom;
                                txtDataNascimento.CustomFormat = "yyyy-MM-dd";
                                if (txtTelefone.Text != "")
                                {
                                    if (txtCelular.Text != "")
                                    {
                                        if (txtCep.Text != "")
                                        {
                                            if (txtCargo.Text != "")
                                            {
                                                if (txtEstado.Text != "")
                                                {
                                                    if (txtCidade.Text != "")
                                                    {
                                                        if (txtEndereco.Text != "")
                                                        {
                                                            if (txtBairro.Text != "")
                                                            {
                                                                if (txtcd.Text == "")
                                                                {
                                                                    model.InserirFuncionario(tb);
                                                                    MessageBox.Show("O Funcionário foi Cadastrado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                                    LimparCampos();
                                                                }
                                                                else
                                                                {
                                                                    tb.Cd_funcionario = int.Parse(txtcd.Text);
                                                                    model.AtualizarFuncionario(tb);
                                                                    MessageBox.Show("O Funcionário foi Atualizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                                    LimparCampos();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Selecione um CARGO e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                HabilitarCampos();
                                            }
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Preencha o campo do CELULAR e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        HabilitarCampos();
                                        txtCelular.Focus();
                                    }
                                }
                                else
                                {

                                    MessageBox.Show("Preencha o campo do TELEFONE e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    HabilitarCampos();
                                    txtTelefone.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Preencha o campo da DATA DE NASCIMENTO e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                HabilitarCampos();
                                txtDataNascimento.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Preencha o campo do CPF e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            HabilitarCampos();
                            txtCpf.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o campo do RG e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        HabilitarCampos();
                        txtCpf.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Preencha o campo do NOME e tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HabilitarCampos();
                    txtCpf.Focus();
                }
                CarregarGrid();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Desabilitar();
            if (txtcd.Text != "")
            {

                var result = MessageBox.Show("Deseja realmente excluir o registro selecionado?", "Eclusão Usuário!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    model.ExcluirFuncionario(txtcd.Text);
                    MessageBox.Show("O Funcionário foi Excluído com sucesso!", "Exclusão com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    CarregarGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione algum Funcionário e tente novamente!", "Erro ao excluir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GridFuncionario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcd.Text = GridFuncionario.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = GridFuncionario.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtCargo.Text = GridFuncionario.Rows[e.RowIndex].Cells[2].Value.ToString();
            //txtDataNascimento.Text = GridFuncionario.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtRg.Text = GridFuncionario.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtCpf.Text = GridFuncionario.Rows[e.RowIndex].Cells[5].Value.ToString();

            txtTelefone.Text = GridFuncionario.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtCelular.Text = GridFuncionario.Rows[e.RowIndex].Cells[7].Value.ToString();

            txtCep.Text = GridFuncionario.Rows[e.RowIndex].Cells[8].Value.ToString();
            txtEstado.Text = GridFuncionario.Rows[e.RowIndex].Cells[9].Value.ToString();
            txtCidade.Text = GridFuncionario.Rows[e.RowIndex].Cells[10].Value.ToString();
            txtEndereco.Text = GridFuncionario.Rows[e.RowIndex].Cells[11].Value.ToString();
            txtBairro.Text = GridFuncionario.Rows[e.RowIndex].Cells[12].Value.ToString();
            HabilitarCampos();
            btnSalvar.Enabled = true;
        }
        private void HabilitarCampos()
        {
            txtNome.Enabled = true;
            txtRg.Enabled = true;
            txtCpf.Enabled = true;
            txtDataNascimento.Enabled = true;
            txtTelefone.Enabled = true;
            txtCelular.Enabled = true;

            txtCargo.Enabled = true;
            txtCep.Enabled = true;
            txtEstado.Enabled = true;
            txtCidade.Enabled = true;
            txtEndereco.Enabled = true;
            txtBairro.Enabled = true;
        }

        private void LimparCampos()
        {

            txtcd.Text = "";
            txtNome.Text = "";
            txtRg.Text = "";
            txtCpf.Text = "";
            txtDataNascimento.Text = "";
            txtTelefone.Text = "";
            txtCelular.Text = "";

            txtCargo.Text = "";
            txtCep.Text = "";
            txtEstado.Text = "";
            txtCidade.Text = "";
            txtEndereco.Text = "";
            txtBairro.Text = "";
        }

        private void Desabilitar()
        {
            txtNome.Enabled = false;
            txtRg.Enabled = false;
            txtCpf.Enabled = false;
            txtDataNascimento.Enabled = false;
            txtTelefone.Enabled = false;
            txtCelular.Enabled = false;

            txtCargo.Enabled = false;
            txtCep.Enabled = false;
            txtEstado.Enabled = false;
            txtCidade.Enabled = false;
            txtEndereco.Enabled = false;
            txtBairro.Enabled = false;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void frmCadastrarfuncionario_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_funcionario'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_funcionarioTableAdapter.Fill(this.kafipeganyDataSet.tb_funcionario);

        }
    }
}
