﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Model;
namespace KafipeganyView
{
    public partial class frmEstoque : Form
    {
        ProdutoModel model = new ProdutoModel();
        tb_produto tb = new tb_produto();
        public frmEstoque()
        {
            InitializeComponent();
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmEstoque_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_produto'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_produtoTableAdapter.Fill(this.kafipeganyDataSet.tb_produto);
            CarregarGrid();
        }
        private void CarregarGrid()
        {
            GridEstoque.DataSource = model.SelecionaTodosProdutos();
        }

      

        private void GridProduto_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.GridEstoque.Columns[e.ColumnIndex].Name == "Quantidade")
            {
                if (Convert.ToInt32(e.Value) <= 10)
                {
                    e.CellStyle.ForeColor = Color.Red;
                    e.CellStyle.BackColor = Color.Orange;

                }
            }
        }
    }
}
