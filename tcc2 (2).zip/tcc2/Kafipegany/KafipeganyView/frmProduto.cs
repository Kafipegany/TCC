﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using Kafipegany.Entidades;
namespace KafipeganyView
{
    public partial class frmProduto : Form
    {
        tb_produto tb = new tb_produto();
        ProdutoModel model = new ProdutoModel();
        public frmProduto()
        {
            InitializeComponent();
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            HabilitarCampos();
            txtNome.Focus();
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilitar();
            tb.Nm_produto = txtNome.Text;
            tb.Ds_produto = txtDescricao.Text;
            tb.Qt_produto = txtQuantidade.Text;
            tb.Vl_produto = txtValor.Text;

            if (txtNome.Text == "" && txtDescricao.Text == "" && txtQuantidade.Text == "" && txtValor.Text == "")
            {
                MessageBox.Show("Preencha os campos e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCampos();
            }
            else
            {
                if (txtNome.Text != "")
                {
                    if (txtDescricao.Text != "")
                    {
                        if (txtQuantidade.Text != "")
                        {
                            if (txtValor.Text != "")
                            {
                                if (txtcd.Text == "")
                                {
                                    model.InserirQuarto(tb);
                                    MessageBox.Show("O Produto foi Cadastrado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LimparCampos();
                                }
                                else
                                {
                                    tb.Cd_produto = int.Parse(txtcd.Text);
                                    model.AtualizarQuarto(tb);
                                    MessageBox.Show("O Produto foi Atualizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LimparCampos();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Preencha o campo de Valor  e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                HabilitarCampos();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Preencha o campo de Quantidade e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            HabilitarCampos();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o campo de Descrição e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        HabilitarCampos();
                    }

                }
                else
                {
                    MessageBox.Show("Preencha o campo de Nome do Produto e tente novamente!", "Erro ao Inserir Produto!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HabilitarCampos();
                }
                CarregarGrid();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Desabilitar();
            if (txtcd.Text != "")
            {

                var result = MessageBox.Show("Deseja realmente excluir o registro selecionado?", "Eclusão Usuário!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    model.ExcluirProdutos(txtcd.Text);
                    MessageBox.Show("O Cliente foi Excluído com sucesso!", "Exclusão com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    CarregarGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione algum Cliente e tente novamente!", "Erro ao excluir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void CarregarGrid()
        {
            GridProduto.DataSource = model.SelecionaTodosProdutos();
        }

        private void GridProduto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcd.Text = GridProduto.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = GridProduto.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDescricao.Text = GridProduto.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtQuantidade.Text = GridProduto.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtValor.Text = GridProduto.Rows[e.RowIndex].Cells[3].Value.ToString();
            HabilitarCampos();
            btnSalvar.Enabled = true;
        }

        private void frmProduto_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_produto'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_produtoTableAdapter.Fill(this.kafipeganyDataSet.tb_produto);
            CarregarGrid();
        }
        private void HabilitarCampos()
        {
            txtDescricao.Enabled = true;
            txtNome.Enabled = true;
            txtQuantidade.Enabled = true;
            txtValor.Enabled = true;
        }

        private void LimparCampos()
        {

            txtDescricao.Text = "";
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
        }

        private void Desabilitar()
        {
            txtNome.Enabled = false;
            txtDescricao.Enabled = false;
            txtValor.Enabled = false;
            txtQuantidade.Enabled = false;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
