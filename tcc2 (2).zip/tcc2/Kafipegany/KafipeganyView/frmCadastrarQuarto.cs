﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Model;
namespace KafipeganyView
{
    public partial class frmCadastrarQuarto : Form
    {
        tb_quarto tb = new tb_quarto();
        QuartoModel model = new QuartoModel();
        public frmCadastrarQuarto()
        {
            InitializeComponent();
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            HabilitarCampos();
            txtNumeroQuarto.Focus();
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilitar();
            tb.Nm_quarto = txtNumeroQuarto.Text;
            tb.Ds_quato = txtDescricao.Text;
            tb.Nr_capacidade = txtCapacidade.Text;
            tb.Vl_diaria = txtValor.Text;

            if (txtNumeroQuarto.Text == "" && txtDescricao.Text == "" && txtCapacidade.Text == "")
            {
                MessageBox.Show("Preencha os campos e tente novamente!", "Erro ao Inserir Funcionario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCampos();
            }
            else
            {
                if (txtNumeroQuarto.Text != "")
                {
                    if (txtDescricao.Text != "")
                    {
                        if (txtCapacidade.Text != "")
                        {
                            if (txtcd.Text == "")
                            {
                                model.InserirQuarto(tb);
                                MessageBox.Show("O Funcionário foi Cadastrado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LimparCampos();
                            }
                            else
                            {
                                tb.Cd_quarto = int.Parse(txtcd.Text);
                                model.AtualizarQuarto(tb);
                                MessageBox.Show("O Funcionário foi Atualizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LimparCampos();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Preencha o campo de Capacidade do quarto tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            HabilitarCampos();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o campo de Descrição tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        HabilitarCampos();
                    }
                }
                else
                {
                    MessageBox.Show("Preencha o campo do Número do quarto tente novamente!", "Erro ao Inserir Funcionário!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HabilitarCampos();
                }
                CarregarGrid();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Desabilitar();
            if (txtcd.Text != "")
            {

                var result = MessageBox.Show("Deseja realmente excluir o registro selecionado?", "Eclusão Usuário!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    model.ExcluirQuarto(txtcd.Text);
                    MessageBox.Show("O Quarto foi Excluído com sucesso!", "Exclusão com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    CarregarGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione algum Quarto e tente novamente!", "Erro ao excluir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GridQuarto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtcd.Text = GridQuarto.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNumeroQuarto.Text = GridQuarto.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtValor.Text = GridQuarto.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtDescricao.Text = GridQuarto.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtCapacidade.Text = GridQuarto.Rows[e.RowIndex].Cells[4].Value.ToString();
        }
        private void CarregarGrid()
        {
            GridQuarto.DataSource = model.SelecionaTodosQuartos();
        }
        private void HabilitarCampos()
        {
            txtNumeroQuarto.Enabled = true;
            txtDescricao.Enabled = true;
            txtCapacidade.Enabled = true;
            txtValor.Enabled = true;
        }

        private void LimparCampos()
        {

            txtNumeroQuarto.Text = "";
            txtDescricao.Text = "";
            txtCapacidade.Text = "";
        }

        private void Desabilitar()
        {
            txtNumeroQuarto.Enabled = false;
            txtDescricao.Enabled = false;
            txtCapacidade.Enabled = false;
        }

        private void frmCadastrarQuarto_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_quarto'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_quartoTableAdapter.Fill(this.kafipeganyDataSet.tb_quarto);
            CarregarGrid();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
