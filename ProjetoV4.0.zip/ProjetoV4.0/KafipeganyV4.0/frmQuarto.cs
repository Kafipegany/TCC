﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyV2._0.Cadastros
{
    public partial class frmQuarto : Form
    {
        public frmQuarto()
        {
            InitializeComponent();
        }

        private void tb_quartoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tb_quartoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kafipeganyDataSet);

        }

        private void frmQuarto_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_quarto'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_quartoTableAdapter.Fill(this.kafipeganyDataSet.tb_quarto);

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            tb_quartoBindingSource.AddNew();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Validate();
            tb_quartoBindingSource.EndEdit();
            tb_quartoTableAdapter.Update(this.kafipeganyDataSet.tb_quarto);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tb_quartoBindingSource.Count > 0)
            {

                tb_quartoBindingSource.RemoveCurrent();
                tb_quartoTableAdapter.Update(kafipeganyDataSet.tb_quarto);
            }
            else
            {
                MessageBox.Show("Não há registros a excluir!");
            }
        }

        private void tb_quartoDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
