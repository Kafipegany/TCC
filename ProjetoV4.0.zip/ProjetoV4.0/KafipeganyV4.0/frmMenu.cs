﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyV2._0
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
            MessageBox.Show("O Usuário foi Logado com sucesso!", "Login Valido!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void customizeDesign()
        {
            pnlCadastros.Visible = false;
            pnlProduto.Visible = false;
            pnlReserva.Visible = false;
            pnlMovimentacao.Visible = false;
            pnlCheck.Visible = false;
            pnlRelatorios.Visible = false;

        }
        private void hideSubMenu()
        {
            if (pnlCadastros.Visible == true)
            {
                pnlCadastros.Visible = false;
            }
            if (pnlProduto.Visible == true)
            {
                pnlProduto.Visible = false;
            }
            if (pnlReserva.Visible == true)
            {
                pnlReserva.Visible = false;
            }
            if (pnlMovimentacao.Visible == true)
            {
                pnlMovimentacao.Visible = false;
            }
            if (pnlCheck.Visible == true)
            {
                pnlCheck.Visible = false;
            }
            if (pnlRelatorios.Visible == true)
            {
                pnlRelatorios.Visible = false;
            }
        }
        private void showSubMenu(Panel SubMenu)
        {
            if (SubMenu.Visible == false)
            {
                hideSubMenu();
                SubMenu.Visible = true;
            }
            else
                SubMenu.Visible = false;
        }

        private void btnCadastros_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlCadastros);
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            //Botão de minimizar
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnProdutos_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlProduto);
        }

        private void btnCadastroFuncionario_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form de funcionários
            hideSubMenu();
            //..
            abrirFormHija(new Cadastros.frmCadastroFuncionarios());
        }

        private void btnCadastrosHospedes_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form de cadastro de Hospedes
            abrirFormHija(new Cadastros.frmCadastroHospede());
            hideSubMenu();
        }

        private void btnCadastrosQuartos_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form de cadastro de quartos
            abrirFormHija(new Cadastros.frmQuarto());
          hideSubMenu();
            
        }

    

        private void btnNewProduto_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form de novo produto
            hideSubMenu();
        }

        private void btnProdutoEstoque_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form 
            hideSubMenu();
        }

        private void btnProdutoEstoqueBaixo_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form 
            hideSubMenu();
        }

        private void btnReserva_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlReserva);
        }

        private void btnReservaNewReserva_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form de nova reserva
            hideSubMenu();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Aqui é botão para o form Consultar resrva
            hideSubMenu();
        }

        private void btnChekInOut_Click(object sender, EventArgs e)
        {

            showSubMenu(pnlCheck);
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form do Check In
            hideSubMenu();
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form do Check Out
            hideSubMenu();
        }

        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlRelatorios);
        }

        private void btnRPdt_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form de relatório de produto
            hideSubMenu();
        }

        private void btnRVd_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form de relatório de Vendas
            hideSubMenu();
        }

        private void btnRsvc_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form de relatório 
            hideSubMenu();
        }

        private void btnREs_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form de relatório
            hideSubMenu();
        }

        private void btnRM_Click(object sender, EventArgs e)
        {
            //Aqui é bõtão para o form 
            hideSubMenu();
        }
        private void abrirFormHija(object formhija)
        {
            if (this.btnSlide2.Controls.Count > 0)
                this.btnSlide2.Controls.RemoveAt(0);
            Form fh = formhija as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.btnSlide2.Controls.Add(fh);
            this.btnSlide2.Tag = fh;
            fh.Show();
        }

        private void btnSlide_Click(object sender, EventArgs e)
        {
            if(pnlMenu.Width == 250)
            {
                pnlMenu.Width = 80;
                btnSlide.Visible = false;
                btnSlide3.Visible = true;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (pnlMenu.Width == 80)
            {
                pnlMenu.Width = 250;
                btnSlide.Visible = true;
                btnSlide3.Visible = false;
            }
        }
    }
}
