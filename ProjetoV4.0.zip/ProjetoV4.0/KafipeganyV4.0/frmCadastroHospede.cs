﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyV2._0.Cadastros
{
    public partial class frmCadastroHospede : Form
    {
        public frmCadastroHospede()
        {
            InitializeComponent();
        }

        private void frmCadastroHospede_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_cliente'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_clienteTableAdapter.Fill(this.kafipeganyDataSet.tb_cliente);

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            tbclienteBindingSource.AddNew();
           
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Validate();
            tbclienteBindingSource.EndEdit();
            tb_clienteTableAdapter.Update(this.kafipeganyDataSet.tb_cliente);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbclienteBindingSource.Count > 0)
            {

                tbclienteBindingSource.RemoveCurrent();
                tb_clienteTableAdapter.Update(kafipeganyDataSet.tb_cliente);
            }
            else
            {
                MessageBox.Show("Não há registros a excluir!");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (txtPesquisa.Text == "")
            {
                tb_clienteTableAdapter.Fill(kafipeganyDataSet.tb_cliente);
            }
            else
            {
                //Pesquisar como fazer consulta por cpf
                 
                //Consulta por Nome ↓
                tb_clienteTableAdapter.nm_Nome(kafipeganyDataSet.tb_cliente, "%" + txtPesquisa.Text + "%");
            }
        }

        private void btnNovo_Click_1(object sender, EventArgs e)
        {
            tbclienteBindingSource.AddNew();
        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            Validate();
            tbclienteBindingSource.EndEdit();
            tb_clienteTableAdapter.Update(this.kafipeganyDataSet.tb_cliente);
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tbclienteBindingSource.Count > 0)
            {

                tbclienteBindingSource.RemoveCurrent();
                tb_clienteTableAdapter.Update(kafipeganyDataSet.tb_cliente);
            }
            else
            {
                MessageBox.Show("Não há registros a excluir!");
            }
        }

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            if (txtPesquisa.Text == "")
            {
                tb_clienteTableAdapter.Fill(kafipeganyDataSet.tb_cliente);
            }
            else
            {
                //Pesquisar como fazer consulta por cpf

                tb_clienteTableAdapter.nm_Nome(kafipeganyDataSet.tb_cliente, "%" + txtPesquisa.Text + "%");
            }

        }
    }
}
