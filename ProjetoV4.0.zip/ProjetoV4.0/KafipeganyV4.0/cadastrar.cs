﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KafipeganyV2._0
{
   public class Cadastrar
    {
        internal static readonly string mensagen;
        Conexao conexao = new Conexao();
        MySqlCommand cmd = new MySqlCommand();
        string mensagem ="";
        public Cadastrar(string nome, string senha, string cargo)
        {
            //comando sql
            cmd.CommandText = "insert into tb_usuario (nm_username,nm_cargo,cd_senha) values(@nome, @cargo, @senha)";

            //parametros
            cmd.Parameters.AddWithValue("@nome",nome);
            cmd.Parameters.AddWithValue("@cargo", cargo);
            cmd.Parameters.AddWithValue("@senha", senha);
            //conectar
            try
            {
                cmd.Connection = conexao.conectar();
                cmd.ExecuteNonQuery();
                //desconectar

                conexao.desconectar();
                this.mensagem = "Casdastro sucesso";
            }
            catch (SqlException e)
            {

                this.mensagem = "Erro com o banco";
            }
            //desconectar
        }
    }
}
