﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyV2._0.Cadastros
{
    public partial class frmCadastroFuncionarios : Form
    {
        public frmCadastroFuncionarios()
        {
            InitializeComponent();
        }

        private void tb_funcionarioBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tb_funcionarioBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kafipeganyDataSet);

        }

        private void frmCadastroFuncionarios_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_funcionario'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_funcionarioTableAdapter.Fill(this.kafipeganyDataSet.tb_funcionario);

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (txtPesquisa.Text == "")
            {
                tb_funcionarioTableAdapter.Fill(kafipeganyDataSet.tb_funcionario);
            }
            else
            {
                tb_funcionarioTableAdapter.nm_Nome(kafipeganyDataSet.tb_funcionario, "%" + txtPesquisa.Text + "%");
            }
        }



        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tb_funcionarioBindingSource.Count > 0)
            {

                tb_funcionarioBindingSource.RemoveCurrent();
                tb_funcionarioTableAdapter.Update(kafipeganyDataSet.tb_funcionario);
            }
            else
            {
                MessageBox.Show("Não há registros a excluir!");
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {

            tb_funcionarioBindingSource.AddNew();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Validate();
            tb_funcionarioBindingSource.EndEdit();
            tb_funcionarioTableAdapter.Update(this.kafipeganyDataSet.tb_funcionario);
        }

        private void pnlTopo_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}