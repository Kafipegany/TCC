﻿
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Kafipegany.Model;




namespace KafipeganyV2._0.Formulários
{
    public partial class Login : Form
    {
        UsuarioModel model = new UsuarioModel();
        tb_usuario tb = new tb_usuario();
        public Login()
        {
            InitializeComponent();
            pnlLogin.Visible = false;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //Comando Para Centralizar o Painel 
            pnlLogin.Location = new Point(this.Width / 2 - 183 , this.Height /2 - 229);
            pnlLogin.Visible = true;

        }

        //Botão para entrar no form menu
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string conexao = "server=localhost;user id=root;password=usbw; database=kafipegany;";
            var connection = new MySqlConnection(conexao);
            var comand = connection.CreateCommand();
            MySqlCommand query = new MySqlCommand("select count(*) from tb_usuario where nm_username = '" + txtUsername.Text + "' and cd_senha = '" + txtSenha.Text + "'", connection);
            connection.Open();

            DataTable dataTable = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(query);
            da.Fill(dataTable);

            foreach(DataRow list in dataTable.Rows)
            {
                if (Convert.ToInt32(list.ItemArray[0]) > 0)
                {
                   
                    frmMenu frm = new frmMenu();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("O usuário não foi encontardo!", "Login Invalido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            connection.Close();
            

        }
        


        //Link que chama o form de cadastro de Usuarios
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCadastrarUsuario form = new frmCadastrarUsuario();
            form.Show();
        }


        //Botão "X"
        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        //Botão "-"
        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            //Botão de minimizar
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
