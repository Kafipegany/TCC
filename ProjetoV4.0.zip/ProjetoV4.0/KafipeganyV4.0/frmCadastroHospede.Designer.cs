﻿namespace KafipeganyV2._0.Cadastros
{
    partial class frmCadastroHospede
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nm_clienteLabel;
            System.Windows.Forms.Label cd_rgLabel;
            System.Windows.Forms.Label cd_cpfLabel;
            System.Windows.Forms.Label dt_nascimentoLabel;
            System.Windows.Forms.Label ds_telefoneLabel;
            System.Windows.Forms.Label ds_celularLabel;
            System.Windows.Forms.Label ds_emailLabel;
            System.Windows.Forms.Label ds_estadocivilLabel;
            System.Windows.Forms.Label ds_veiculoLabel;
            System.Windows.Forms.Label ds_tipoVeiculoLabel;
            System.Windows.Forms.Label cd_CnpjLabel;
            System.Windows.Forms.Label cd_InscricaoEstadualLabel;
            System.Windows.Forms.Label cd_placaVeiculoLabel;
            System.Windows.Forms.Label cd_CepLabel;
            System.Windows.Forms.Label nm_estadoLabel;
            System.Windows.Forms.Label nm_cidadeLabel;
            System.Windows.Forms.Label ds_enderecoLabel;
            System.Windows.Forms.Label nm_bairroLabel;
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastroHospede));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtPesquisa = new System.Windows.Forms.ComboBox();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.dt_nascimentoDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tb_clienteDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbclienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kafipeganyDataSet = new KafipeganyV2._0.kafipeganyDataSet();
            this.tb_clienteTableAdapter = new KafipeganyV2._0.kafipeganyDataSetTableAdapters.tb_clienteTableAdapter();
            this.tableAdapterManager = new KafipeganyV2._0.kafipeganyDataSetTableAdapters.TableAdapterManager();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            nm_clienteLabel = new System.Windows.Forms.Label();
            cd_rgLabel = new System.Windows.Forms.Label();
            cd_cpfLabel = new System.Windows.Forms.Label();
            dt_nascimentoLabel = new System.Windows.Forms.Label();
            ds_telefoneLabel = new System.Windows.Forms.Label();
            ds_celularLabel = new System.Windows.Forms.Label();
            ds_emailLabel = new System.Windows.Forms.Label();
            ds_estadocivilLabel = new System.Windows.Forms.Label();
            ds_veiculoLabel = new System.Windows.Forms.Label();
            ds_tipoVeiculoLabel = new System.Windows.Forms.Label();
            cd_CnpjLabel = new System.Windows.Forms.Label();
            cd_InscricaoEstadualLabel = new System.Windows.Forms.Label();
            cd_placaVeiculoLabel = new System.Windows.Forms.Label();
            cd_CepLabel = new System.Windows.Forms.Label();
            nm_estadoLabel = new System.Windows.Forms.Label();
            nm_cidadeLabel = new System.Windows.Forms.Label();
            ds_enderecoLabel = new System.Windows.Forms.Label();
            nm_bairroLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_clienteDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // nm_clienteLabel
            // 
            nm_clienteLabel.AutoSize = true;
            nm_clienteLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nm_clienteLabel.Location = new System.Drawing.Point(20, 16);
            nm_clienteLabel.Name = "nm_clienteLabel";
            nm_clienteLabel.Size = new System.Drawing.Size(55, 19);
            nm_clienteLabel.TabIndex = 40;
            nm_clienteLabel.Text = "Nome:";
            // 
            // cd_rgLabel
            // 
            cd_rgLabel.AutoSize = true;
            cd_rgLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_rgLabel.Location = new System.Drawing.Point(278, 16);
            cd_rgLabel.Name = "cd_rgLabel";
            cd_rgLabel.Size = new System.Drawing.Size(34, 19);
            cd_rgLabel.TabIndex = 41;
            cd_rgLabel.Text = "RG:";
            // 
            // cd_cpfLabel
            // 
            cd_cpfLabel.AutoSize = true;
            cd_cpfLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_cpfLabel.Location = new System.Drawing.Point(407, 16);
            cd_cpfLabel.Name = "cd_cpfLabel";
            cd_cpfLabel.Size = new System.Drawing.Size(41, 19);
            cd_cpfLabel.TabIndex = 42;
            cd_cpfLabel.Text = "CPF:";
            // 
            // dt_nascimentoLabel
            // 
            dt_nascimentoLabel.AutoSize = true;
            dt_nascimentoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            dt_nascimentoLabel.Location = new System.Drawing.Point(552, 16);
            dt_nascimentoLabel.Name = "dt_nascimentoLabel";
            dt_nascimentoLabel.Size = new System.Drawing.Size(161, 19);
            dt_nascimentoLabel.TabIndex = 43;
            dt_nascimentoLabel.Text = "Data de Nascimento:";
            // 
            // ds_telefoneLabel
            // 
            ds_telefoneLabel.AutoSize = true;
            ds_telefoneLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_telefoneLabel.Location = new System.Drawing.Point(743, 16);
            ds_telefoneLabel.Name = "ds_telefoneLabel";
            ds_telefoneLabel.Size = new System.Drawing.Size(75, 19);
            ds_telefoneLabel.TabIndex = 44;
            ds_telefoneLabel.Text = "Telefone:";
            // 
            // ds_celularLabel
            // 
            ds_celularLabel.AutoSize = true;
            ds_celularLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_celularLabel.Location = new System.Drawing.Point(888, 16);
            ds_celularLabel.Name = "ds_celularLabel";
            ds_celularLabel.Size = new System.Drawing.Size(66, 19);
            ds_celularLabel.TabIndex = 45;
            ds_celularLabel.Text = "Celular:";
            // 
            // ds_emailLabel
            // 
            ds_emailLabel.AutoSize = true;
            ds_emailLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_emailLabel.Location = new System.Drawing.Point(20, 87);
            ds_emailLabel.Name = "ds_emailLabel";
            ds_emailLabel.Size = new System.Drawing.Size(60, 19);
            ds_emailLabel.TabIndex = 46;
            ds_emailLabel.Text = "E-mail:";
            // 
            // ds_estadocivilLabel
            // 
            ds_estadocivilLabel.AutoSize = true;
            ds_estadocivilLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_estadocivilLabel.Location = new System.Drawing.Point(278, 87);
            ds_estadocivilLabel.Name = "ds_estadocivilLabel";
            ds_estadocivilLabel.Size = new System.Drawing.Size(99, 19);
            ds_estadocivilLabel.TabIndex = 47;
            ds_estadocivilLabel.Text = "Estado Civil:";
            // 
            // ds_veiculoLabel
            // 
            ds_veiculoLabel.AutoSize = true;
            ds_veiculoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_veiculoLabel.Location = new System.Drawing.Point(421, 87);
            ds_veiculoLabel.Name = "ds_veiculoLabel";
            ds_veiculoLabel.Size = new System.Drawing.Size(199, 19);
            ds_veiculoLabel.TabIndex = 48;
            ds_veiculoLabel.Text = "Nome e Marca do Veículo:";
            // 
            // ds_tipoVeiculoLabel
            // 
            ds_tipoVeiculoLabel.AutoSize = true;
            ds_tipoVeiculoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_tipoVeiculoLabel.Location = new System.Drawing.Point(676, 87);
            ds_tipoVeiculoLabel.Name = "ds_tipoVeiculoLabel";
            ds_tipoVeiculoLabel.Size = new System.Drawing.Size(105, 19);
            ds_tipoVeiculoLabel.TabIndex = 49;
            ds_tipoVeiculoLabel.Text = "Tipo Veículo:";
            // 
            // cd_CnpjLabel
            // 
            cd_CnpjLabel.AutoSize = true;
            cd_CnpjLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_CnpjLabel.Location = new System.Drawing.Point(918, 87);
            cd_CnpjLabel.Name = "cd_CnpjLabel";
            cd_CnpjLabel.Size = new System.Drawing.Size(48, 19);
            cd_CnpjLabel.TabIndex = 50;
            cd_CnpjLabel.Text = "CNPJ:";
            // 
            // cd_InscricaoEstadualLabel
            // 
            cd_InscricaoEstadualLabel.AutoSize = true;
            cd_InscricaoEstadualLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_InscricaoEstadualLabel.Location = new System.Drawing.Point(20, 161);
            cd_InscricaoEstadualLabel.Name = "cd_InscricaoEstadualLabel";
            cd_InscricaoEstadualLabel.Size = new System.Drawing.Size(151, 19);
            cd_InscricaoEstadualLabel.TabIndex = 51;
            cd_InscricaoEstadualLabel.Text = "Inscrição Estadual:";
            // 
            // cd_placaVeiculoLabel
            // 
            cd_placaVeiculoLabel.AutoSize = true;
            cd_placaVeiculoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_placaVeiculoLabel.Location = new System.Drawing.Point(799, 87);
            cd_placaVeiculoLabel.Name = "cd_placaVeiculoLabel";
            cd_placaVeiculoLabel.Size = new System.Drawing.Size(54, 19);
            cd_placaVeiculoLabel.TabIndex = 52;
            cd_placaVeiculoLabel.Text = "Placa:";
            // 
            // cd_CepLabel
            // 
            cd_CepLabel.AutoSize = true;
            cd_CepLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            cd_CepLabel.Location = new System.Drawing.Point(193, 161);
            cd_CepLabel.Name = "cd_CepLabel";
            cd_CepLabel.Size = new System.Drawing.Size(41, 19);
            cd_CepLabel.TabIndex = 53;
            cd_CepLabel.Text = "CEP:";
            // 
            // nm_estadoLabel
            // 
            nm_estadoLabel.AutoSize = true;
            nm_estadoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nm_estadoLabel.Location = new System.Drawing.Point(304, 161);
            nm_estadoLabel.Name = "nm_estadoLabel";
            nm_estadoLabel.Size = new System.Drawing.Size(63, 19);
            nm_estadoLabel.TabIndex = 54;
            nm_estadoLabel.Text = "Estado:";
            // 
            // nm_cidadeLabel
            // 
            nm_cidadeLabel.AutoSize = true;
            nm_cidadeLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nm_cidadeLabel.Location = new System.Drawing.Point(472, 161);
            nm_cidadeLabel.Name = "nm_cidadeLabel";
            nm_cidadeLabel.Size = new System.Drawing.Size(64, 19);
            nm_cidadeLabel.TabIndex = 55;
            nm_cidadeLabel.Text = "Cidade:";
            // 
            // ds_enderecoLabel
            // 
            ds_enderecoLabel.AutoSize = true;
            ds_enderecoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_enderecoLabel.Location = new System.Drawing.Point(641, 161);
            ds_enderecoLabel.Name = "ds_enderecoLabel";
            ds_enderecoLabel.Size = new System.Drawing.Size(82, 19);
            ds_enderecoLabel.TabIndex = 56;
            ds_enderecoLabel.Text = "Endereço:";
            // 
            // nm_bairroLabel
            // 
            nm_bairroLabel.AutoSize = true;
            nm_bairroLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nm_bairroLabel.Location = new System.Drawing.Point(894, 161);
            nm_bairroLabel.Name = "nm_bairroLabel";
            nm_bairroLabel.Size = new System.Drawing.Size(60, 19);
            nm_bairroLabel.TabIndex = 59;
            nm_bairroLabel.Text = "Bairro:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            label1.Location = new System.Drawing.Point(206, 68);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(55, 19);
            label1.TabIndex = 6;
            label1.Text = "Nome:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(label1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.txtPesquisa);
            this.panel2.Controls.Add(this.btnPesquisar);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1494, 505);
            this.panel2.TabIndex = 1;
            // 
            // txtPesquisa
            // 
            this.txtPesquisa.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPesquisa.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtPesquisa.FormattingEnabled = true;
            this.txtPesquisa.Location = new System.Drawing.Point(267, 66);
            this.txtPesquisa.Name = "txtPesquisa";
            this.txtPesquisa.Size = new System.Drawing.Size(456, 21);
            this.txtPesquisa.TabIndex = 34;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPesquisar.BackgroundImage")));
            this.btnPesquisar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPesquisar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisar.FlatAppearance.BorderSize = 0;
            this.btnPesquisar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Location = new System.Drawing.Point(729, 68);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(37, 21);
            this.btnPesquisar.TabIndex = 33;
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click_1);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightCyan;
            this.panel4.Controls.Add(this.btnSair);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 925);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1494, 70);
            this.panel4.TabIndex = 3;
            // 
            // btnSair
            // 
            this.btnSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSair.BackgroundImage")));
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Location = new System.Drawing.Point(1429, 0);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(65, 70);
            this.btnSair.TabIndex = 61;
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Location = new System.Drawing.Point(1100, 32);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(40, 45);
            this.btnNovo.TabIndex = 60;
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click_1);
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExcluir.BackgroundImage")));
            this.btnExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Location = new System.Drawing.Point(1105, 161);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(45, 45);
            this.btnExcluir.TabIndex = 58;
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click_1);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalvar.BackgroundImage")));
            this.btnSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Location = new System.Drawing.Point(1105, 100);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(35, 45);
            this.btnSalvar.TabIndex = 57;
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click_1);
            // 
            // textBox11
            // 
            this.textBox11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "nm_bairro", true));
            this.textBox11.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox11.Location = new System.Drawing.Point(895, 183);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(160, 26);
            this.textBox11.TabIndex = 77;
            // 
            // textBox10
            // 
            this.textBox10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_endereco", true));
            this.textBox10.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox10.Location = new System.Drawing.Point(644, 183);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(234, 26);
            this.textBox10.TabIndex = 76;
            // 
            // textBox9
            // 
            this.textBox9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "nm_cidade", true));
            this.textBox9.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox9.Location = new System.Drawing.Point(476, 183);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(148, 26);
            this.textBox9.TabIndex = 75;
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "nm_estado", true));
            this.textBox8.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox8.Location = new System.Drawing.Point(308, 183);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(147, 26);
            this.textBox8.TabIndex = 74;
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_Cep", true));
            this.maskedTextBox6.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox6.Location = new System.Drawing.Point(194, 183);
            this.maskedTextBox6.Mask = "00000-000";
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(93, 26);
            this.maskedTextBox6.TabIndex = 73;
            // 
            // textBox7
            // 
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_InscricaoEstadual", true));
            this.textBox7.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox7.Location = new System.Drawing.Point(24, 183);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(141, 26);
            this.textBox7.TabIndex = 72;
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_Cnpj", true));
            this.maskedTextBox5.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox5.Location = new System.Drawing.Point(922, 110);
            this.maskedTextBox5.Mask = "00,000,000/0000-00";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(124, 26);
            this.maskedTextBox5.TabIndex = 71;
            // 
            // textBox6
            // 
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_placaVeiculo", true));
            this.textBox6.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox6.Location = new System.Drawing.Point(799, 109);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(105, 26);
            this.textBox6.TabIndex = 70;
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_tipoVeiculo", true));
            this.textBox5.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox5.Location = new System.Drawing.Point(678, 109);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(106, 26);
            this.textBox5.TabIndex = 69;
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_veiculo", true));
            this.textBox4.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox4.Location = new System.Drawing.Point(425, 109);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(233, 26);
            this.textBox4.TabIndex = 68;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_estadocivil", true));
            this.textBox3.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox3.Location = new System.Drawing.Point(282, 109);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(122, 26);
            this.textBox3.TabIndex = 67;
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_email", true));
            this.textBox2.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox2.Location = new System.Drawing.Point(24, 109);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(231, 26);
            this.textBox2.TabIndex = 66;
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_celular", true));
            this.maskedTextBox4.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox4.Location = new System.Drawing.Point(892, 38);
            this.maskedTextBox4.Mask = "(99)0000-00000";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(129, 26);
            this.maskedTextBox4.TabIndex = 65;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "ds_telefone", true));
            this.maskedTextBox3.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox3.Location = new System.Drawing.Point(747, 38);
            this.maskedTextBox3.Mask = "(99) 0000-0000";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(124, 26);
            this.maskedTextBox3.TabIndex = 64;
            // 
            // dt_nascimentoDateTimePicker
            // 
            this.dt_nascimentoDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbclienteBindingSource, "dt_nascimento", true));
            this.dt_nascimentoDateTimePicker.Font = new System.Drawing.Font("Cambria", 12F);
            this.dt_nascimentoDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dt_nascimentoDateTimePicker.Location = new System.Drawing.Point(557, 38);
            this.dt_nascimentoDateTimePicker.Name = "dt_nascimentoDateTimePicker";
            this.dt_nascimentoDateTimePicker.Size = new System.Drawing.Size(132, 26);
            this.dt_nascimentoDateTimePicker.TabIndex = 63;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_cpf", true));
            this.maskedTextBox2.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox2.Location = new System.Drawing.Point(411, 39);
            this.maskedTextBox2.Mask = "000,000,000-00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(125, 26);
            this.maskedTextBox2.TabIndex = 62;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "cd_rg", true));
            this.maskedTextBox1.Font = new System.Drawing.Font("Cambria", 12F);
            this.maskedTextBox1.Location = new System.Drawing.Point(282, 39);
            this.maskedTextBox1.Mask = "00,000,000-0";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(106, 26);
            this.maskedTextBox1.TabIndex = 61;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbclienteBindingSource, "nm_cliente", true));
            this.textBox1.Font = new System.Drawing.Font("Cambria", 12F);
            this.textBox1.Location = new System.Drawing.Point(24, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(234, 26);
            this.textBox1.TabIndex = 60;
            // 
            // tb_clienteDataGridView
            // 
            this.tb_clienteDataGridView.AutoGenerateColumns = false;
            this.tb_clienteDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.tb_clienteDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tb_clienteDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.tb_clienteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tb_clienteDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19});
            this.tb_clienteDataGridView.DataSource = this.tbclienteBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tb_clienteDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.tb_clienteDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_clienteDataGridView.Location = new System.Drawing.Point(70, 505);
            this.tb_clienteDataGridView.Name = "tb_clienteDataGridView";
            this.tb_clienteDataGridView.Size = new System.Drawing.Size(1354, 420);
            this.tb_clienteDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "cd_cliente";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nm_cliente";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nome";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "cd_rg";
            this.dataGridViewTextBoxColumn3.HeaderText = "RG";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "cd_cpf";
            this.dataGridViewTextBoxColumn4.HeaderText = "CPF";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "dt_nascimento";
            this.dataGridViewTextBoxColumn5.HeaderText = "Data de Nascimento";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ds_telefone";
            this.dataGridViewTextBoxColumn6.HeaderText = "Telefone";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ds_celular";
            this.dataGridViewTextBoxColumn7.HeaderText = "Celular";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ds_email";
            this.dataGridViewTextBoxColumn8.HeaderText = "E-mail";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 150;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ds_estadocivil";
            this.dataGridViewTextBoxColumn9.HeaderText = "Estado Civil";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "ds_veiculo";
            this.dataGridViewTextBoxColumn10.HeaderText = "Veículo";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 120;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "ds_tipoVeiculo";
            this.dataGridViewTextBoxColumn11.HeaderText = "Tipo Veículo";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "cd_Cnpj";
            this.dataGridViewTextBoxColumn12.HeaderText = "CNPJ";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 80;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "cd_InscricaoEstadual";
            this.dataGridViewTextBoxColumn13.HeaderText = "Inscrição Estadual";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "cd_placaVeiculo";
            this.dataGridViewTextBoxColumn14.HeaderText = "Placa";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 80;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "cd_Cep";
            this.dataGridViewTextBoxColumn15.HeaderText = "CEP";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Width = 90;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "nm_estado";
            this.dataGridViewTextBoxColumn16.HeaderText = "Estado";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Width = 130;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "nm_cidade";
            this.dataGridViewTextBoxColumn17.HeaderText = "Cidade";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Width = 150;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "ds_endereco";
            this.dataGridViewTextBoxColumn18.HeaderText = "Endereço";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.Width = 150;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "nm_bairro";
            this.dataGridViewTextBoxColumn19.HeaderText = "Bairro";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.Width = 130;
            // 
            // tbclienteBindingSource
            // 
            this.tbclienteBindingSource.DataMember = "tb_cliente";
            this.tbclienteBindingSource.DataSource = this.kafipeganyDataSet;
            // 
            // kafipeganyDataSet
            // 
            this.kafipeganyDataSet.DataSetName = "kafipeganyDataSet";
            this.kafipeganyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_clienteTableAdapter
            // 
            this.tb_clienteTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tb_clienteTableAdapter = this.tb_clienteTableAdapter;
            this.tableAdapterManager.tb_contaTableAdapter = null;
            this.tableAdapterManager.tb_funcionarioTableAdapter = null;
            this.tableAdapterManager.tb_manutencaoTableAdapter = null;
            this.tableAdapterManager.tb_produtoTableAdapter = null;
            this.tableAdapterManager.tb_quarto_manutencaoTableAdapter = null;
            this.tableAdapterManager.tb_quartoTableAdapter = null;
            this.tableAdapterManager.tb_reserva_produtoTableAdapter = null;
            this.tableAdapterManager.tb_reservaTableAdapter = null;
            this.tableAdapterManager.tb_usuarioTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = KafipeganyV2._0.kafipeganyDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(nm_clienteLabel);
            this.groupBox2.Controls.Add(this.btnNovo);
            this.groupBox2.Controls.Add(this.btnExcluir);
            this.groupBox2.Controls.Add(this.textBox11);
            this.groupBox2.Controls.Add(this.btnSalvar);
            this.groupBox2.Controls.Add(ds_veiculoLabel);
            this.groupBox2.Controls.Add(ds_estadocivilLabel);
            this.groupBox2.Controls.Add(nm_bairroLabel);
            this.groupBox2.Controls.Add(ds_tipoVeiculoLabel);
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Controls.Add(ds_emailLabel);
            this.groupBox2.Controls.Add(this.maskedTextBox3);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Controls.Add(ds_telefoneLabel);
            this.groupBox2.Controls.Add(ds_enderecoLabel);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.dt_nascimentoDateTimePicker);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(cd_placaVeiculoLabel);
            this.groupBox2.Controls.Add(cd_rgLabel);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(nm_cidadeLabel);
            this.groupBox2.Controls.Add(cd_CnpjLabel);
            this.groupBox2.Controls.Add(this.maskedTextBox6);
            this.groupBox2.Controls.Add(dt_nascimentoLabel);
            this.groupBox2.Controls.Add(ds_celularLabel);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.maskedTextBox2);
            this.groupBox2.Controls.Add(nm_estadoLabel);
            this.groupBox2.Controls.Add(cd_InscricaoEstadualLabel);
            this.groupBox2.Controls.Add(this.maskedTextBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.maskedTextBox5);
            this.groupBox2.Controls.Add(cd_cpfLabel);
            this.groupBox2.Controls.Add(this.maskedTextBox1);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(cd_CepLabel);
            this.groupBox2.Location = new System.Drawing.Point(200, 187);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1161, 218);
            this.groupBox2.TabIndex = 78;
            this.groupBox2.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 505);
            this.panel3.TabIndex = 79;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 505);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(70, 420);
            this.panel1.TabIndex = 42;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightCyan;
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(1424, 505);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(70, 420);
            this.panel6.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 16F);
            this.label2.Location = new System.Drawing.Point(341, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(243, 28);
            this.label2.TabIndex = 81;
            this.label2.Text = "Pesquisar Hóspedes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 16F);
            this.label3.Location = new System.Drawing.Point(635, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 28);
            this.label3.TabIndex = 82;
            this.label3.Text = "Lista de Hóspedes";
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(1329, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(165, 505);
            this.panel5.TabIndex = 80;
            // 
            // frmCadastroHospede
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 995);
            this.Controls.Add(this.tb_clienteDataGridView);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCadastroHospede";
            this.Text = "frmCadastroHospede";
            this.Load += new System.EventHandler(this.frmCadastroHospede_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tb_clienteDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbclienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private kafipeganyDataSet kafipeganyDataSet;
        private System.Windows.Forms.BindingSource tbclienteBindingSource;
        private kafipeganyDataSetTableAdapters.tb_clienteTableAdapter tb_clienteTableAdapter;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private kafipeganyDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tb_clienteDataGridView;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.DateTimePicker dt_nascimentoDateTimePicker;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ComboBox txtPesquisa;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
    }
}