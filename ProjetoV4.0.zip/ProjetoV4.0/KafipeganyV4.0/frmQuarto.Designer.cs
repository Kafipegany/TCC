﻿namespace KafipeganyV2._0.Cadastros
{
    partial class frmQuarto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nm_quartoLabel;
            System.Windows.Forms.Label nr_capacidadeLabel;
            System.Windows.Forms.Label ds_statusLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuarto));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nm_quartoTextBox = new System.Windows.Forms.TextBox();
            this.tb_quartoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kafipeganyDataSet = new KafipeganyV2._0.kafipeganyDataSet();
            this.nr_capacidadeTextBox = new System.Windows.Forms.TextBox();
            this.ds_statusTextBox = new System.Windows.Forms.TextBox();
            this.tb_quartoDataGridView = new System.Windows.Forms.DataGridView();
            this.cdquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nrcapacidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idreservaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_quartoTableAdapter = new KafipeganyV2._0.kafipeganyDataSetTableAdapters.tb_quartoTableAdapter();
            this.tableAdapterManager = new KafipeganyV2._0.kafipeganyDataSetTableAdapters.TableAdapterManager();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            nm_quartoLabel = new System.Windows.Forms.Label();
            nr_capacidadeLabel = new System.Windows.Forms.Label();
            ds_statusLabel = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_quartoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_quartoDataGridView)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // nm_quartoLabel
            // 
            nm_quartoLabel.AutoSize = true;
            nm_quartoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nm_quartoLabel.Location = new System.Drawing.Point(11, 16);
            nm_quartoLabel.Name = "nm_quartoLabel";
            nm_quartoLabel.Size = new System.Drawing.Size(220, 19);
            nm_quartoLabel.TabIndex = 6;
            nm_quartoLabel.Text = "Nome ou Número do Quarto:";
            // 
            // nr_capacidadeLabel
            // 
            nr_capacidadeLabel.AutoSize = true;
            nr_capacidadeLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            nr_capacidadeLabel.Location = new System.Drawing.Point(254, 16);
            nr_capacidadeLabel.Name = "nr_capacidadeLabel";
            nr_capacidadeLabel.Size = new System.Drawing.Size(179, 19);
            nr_capacidadeLabel.TabIndex = 8;
            nr_capacidadeLabel.Text = "Capacidade do Quarto:";
            // 
            // ds_statusLabel
            // 
            ds_statusLabel.AutoSize = true;
            ds_statusLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            ds_statusLabel.Location = new System.Drawing.Point(11, 75);
            ds_statusLabel.Name = "ds_statusLabel";
            ds_statusLabel.Size = new System.Drawing.Size(164, 19);
            ds_statusLabel.TabIndex = 10;
            ds_statusLabel.Text = "Descrição do Quarto:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.Controls.Add(this.btnSair);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 718);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1386, 70);
            this.panel3.TabIndex = 2;
            // 
            // btnSair
            // 
            this.btnSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSair.BackgroundImage")));
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Location = new System.Drawing.Point(1321, 0);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(65, 70);
            this.btnSair.TabIndex = 64;
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Location = new System.Drawing.Point(450, 4);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(40, 45);
            this.btnNovo.TabIndex = 63;
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExcluir.BackgroundImage")));
            this.btnExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Location = new System.Drawing.Point(450, 100);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(45, 45);
            this.btnExcluir.TabIndex = 62;
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalvar.BackgroundImage")));
            this.btnSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Location = new System.Drawing.Point(450, 49);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(35, 45);
            this.btnSalvar.TabIndex = 61;
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightCyan;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1386, 505);
            this.panel4.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 16F);
            this.label3.Location = new System.Drawing.Point(695, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(268, 28);
            this.label3.TabIndex = 65;
            this.label3.Text = "Cadastro de Quartos";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(nm_quartoLabel);
            this.groupBox1.Controls.Add(this.nm_quartoTextBox);
            this.groupBox1.Controls.Add(this.btnNovo);
            this.groupBox1.Controls.Add(this.nr_capacidadeTextBox);
            this.groupBox1.Controls.Add(nr_capacidadeLabel);
            this.groupBox1.Controls.Add(ds_statusLabel);
            this.groupBox1.Controls.Add(this.btnExcluir);
            this.groupBox1.Controls.Add(this.btnSalvar);
            this.groupBox1.Controls.Add(this.ds_statusTextBox);
            this.groupBox1.Location = new System.Drawing.Point(588, 216);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(507, 154);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            // 
            // nm_quartoTextBox
            // 
            this.nm_quartoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_quartoBindingSource, "nm_quarto", true));
            this.nm_quartoTextBox.Location = new System.Drawing.Point(11, 38);
            this.nm_quartoTextBox.Name = "nm_quartoTextBox";
            this.nm_quartoTextBox.Size = new System.Drawing.Size(220, 20);
            this.nm_quartoTextBox.TabIndex = 7;
            // 
            // tb_quartoBindingSource
            // 
            this.tb_quartoBindingSource.DataMember = "tb_quarto";
            this.tb_quartoBindingSource.DataSource = this.kafipeganyDataSet;
            // 
            // kafipeganyDataSet
            // 
            this.kafipeganyDataSet.DataSetName = "kafipeganyDataSet";
            this.kafipeganyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nr_capacidadeTextBox
            // 
            this.nr_capacidadeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_quartoBindingSource, "nr_capacidade", true));
            this.nr_capacidadeTextBox.Location = new System.Drawing.Point(258, 38);
            this.nr_capacidadeTextBox.Name = "nr_capacidadeTextBox";
            this.nr_capacidadeTextBox.Size = new System.Drawing.Size(54, 20);
            this.nr_capacidadeTextBox.TabIndex = 9;
            // 
            // ds_statusTextBox
            // 
            this.ds_statusTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_quartoBindingSource, "ds_quarto", true));
            this.ds_statusTextBox.Location = new System.Drawing.Point(11, 97);
            this.ds_statusTextBox.Name = "ds_statusTextBox";
            this.ds_statusTextBox.Size = new System.Drawing.Size(422, 20);
            this.ds_statusTextBox.TabIndex = 11;
            // 
            // tb_quartoDataGridView
            // 
            this.tb_quartoDataGridView.AutoGenerateColumns = false;
            this.tb_quartoDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.tb_quartoDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tb_quartoDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.tb_quartoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tb_quartoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cdquartoDataGridViewTextBoxColumn,
            this.nmquartoDataGridViewTextBoxColumn,
            this.nrcapacidadeDataGridViewTextBoxColumn,
            this.dsquartoDataGridViewTextBoxColumn,
            this.idreservaDataGridViewTextBoxColumn});
            this.tb_quartoDataGridView.DataSource = this.tb_quartoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tb_quartoDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.tb_quartoDataGridView.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.tb_quartoDataGridView.Location = new System.Drawing.Point(6, 6);
            this.tb_quartoDataGridView.Name = "tb_quartoDataGridView";
            this.tb_quartoDataGridView.Size = new System.Drawing.Size(954, 626);
            this.tb_quartoDataGridView.TabIndex = 5;
            this.tb_quartoDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tb_quartoDataGridView_CellContentClick);
            // 
            // cdquartoDataGridViewTextBoxColumn
            // 
            this.cdquartoDataGridViewTextBoxColumn.DataPropertyName = "cd_quarto";
            this.cdquartoDataGridViewTextBoxColumn.HeaderText = "ID";
            this.cdquartoDataGridViewTextBoxColumn.Name = "cdquartoDataGridViewTextBoxColumn";
            // 
            // nmquartoDataGridViewTextBoxColumn
            // 
            this.nmquartoDataGridViewTextBoxColumn.DataPropertyName = "nm_quarto";
            this.nmquartoDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nmquartoDataGridViewTextBoxColumn.Name = "nmquartoDataGridViewTextBoxColumn";
            // 
            // nrcapacidadeDataGridViewTextBoxColumn
            // 
            this.nrcapacidadeDataGridViewTextBoxColumn.DataPropertyName = "nr_capacidade";
            this.nrcapacidadeDataGridViewTextBoxColumn.HeaderText = "Capacidade";
            this.nrcapacidadeDataGridViewTextBoxColumn.Name = "nrcapacidadeDataGridViewTextBoxColumn";
            // 
            // dsquartoDataGridViewTextBoxColumn
            // 
            this.dsquartoDataGridViewTextBoxColumn.DataPropertyName = "ds_quarto";
            this.dsquartoDataGridViewTextBoxColumn.HeaderText = "Descrição";
            this.dsquartoDataGridViewTextBoxColumn.Name = "dsquartoDataGridViewTextBoxColumn";
            this.dsquartoDataGridViewTextBoxColumn.Width = 600;
            // 
            // idreservaDataGridViewTextBoxColumn
            // 
            this.idreservaDataGridViewTextBoxColumn.DataPropertyName = "id_reserva";
            this.idreservaDataGridViewTextBoxColumn.HeaderText = "id_reserva";
            this.idreservaDataGridViewTextBoxColumn.Name = "idreservaDataGridViewTextBoxColumn";
            this.idreservaDataGridViewTextBoxColumn.Visible = false;
            // 
            // tb_quartoTableAdapter
            // 
            this.tb_quartoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.estadoTableAdapter = null;
            this.tableAdapterManager.municipioTableAdapter = null;
            this.tableAdapterManager.tb_clienteTableAdapter = null;
            this.tableAdapterManager.tb_contaTableAdapter = null;
            this.tableAdapterManager.tb_funcionarioTableAdapter = null;
            this.tableAdapterManager.tb_manutencaoTableAdapter = null;
            this.tableAdapterManager.tb_produtoTableAdapter = null;
            this.tableAdapterManager.tb_quarto_manutencaoTableAdapter = null;
            this.tableAdapterManager.tb_quartoTableAdapter = this.tb_quartoTableAdapter;
            this.tableAdapterManager.tb_reserva_produtoTableAdapter = null;
            this.tableAdapterManager.tb_reservaTableAdapter = null;
            this.tableAdapterManager.tb_usuarioTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = KafipeganyV2._0.kafipeganyDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 505);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(352, 213);
            this.panel2.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.tb_quartoDataGridView);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(352, 505);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1034, 213);
            this.panel5.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(728, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 213);
            this.panel1.TabIndex = 43;
            // 
            // frmQuarto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmQuarto";
            this.Text = "frmQuarto";
            this.Load += new System.EventHandler(this.frmQuarto_Load);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_quartoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_quartoDataGridView)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private kafipeganyDataSet kafipeganyDataSet;
        private System.Windows.Forms.BindingSource tb_quartoBindingSource;
        private kafipeganyDataSetTableAdapters.tb_quartoTableAdapter tb_quartoTableAdapter;
        private kafipeganyDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tb_quartoDataGridView;
        private System.Windows.Forms.TextBox nm_quartoTextBox;
        private System.Windows.Forms.TextBox nr_capacidadeTextBox;
        private System.Windows.Forms.TextBox ds_statusTextBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nrcapacidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idreservaDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
    }
}