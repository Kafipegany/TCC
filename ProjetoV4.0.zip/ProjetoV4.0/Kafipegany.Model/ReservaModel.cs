﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.DAL;
using Kafipegany.Entidades;
using MySql.Data.MySqlClient;

namespace Kafipegany.Model
{
    class ReservaModel
    {
        AcessoBancodeDados bd;

        public void InserirReserva(tb_reserva tb)
        {
            //
            try
            {
                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_reserva(dt_entrada,dt_saida,ds_valor,dt_data_reserva,id_funcionario,id_cliente,cd_status) VALUES('" + tb.Dt_entrada + "','" + tb.Dt_saida + "','" + tb.Vl_valor + "','" + tb.Vl_valor + "','" + tb.Dt_dataReserva + "','" + tb.Id_funcionario + "','" + tb.Id_cliente + "','" + tb.Cd_status + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar a Reserva: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void AtualizarReserva(tb_reserva tb)
        {
            //
            try
            {
                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "UPDATE tb_reserva set dt_entrada = '" + tb.Dt_entrada + "',dt_saida='" + tb.Dt_saida + "', ds_valor='" + tb.Vl_valor + "', dt_data_reserva='" + tb.Dt_dataReserva + "', id_funcionario='" + tb.Id_funcionario + "', id_cliente='" + tb.Id_cliente + "', cd_status='" + tb.Cd_status + "' where cd_reserva =" + tb.Cd_reserva;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar atualizar a reserva: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public DataTable SelecionaTodasReservas()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBancodeDados();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_reserva, dt_entrada, d_saida, ds_valor, dt_data_reserva, id_funcionario, id_cliente, cd_status");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todas as Reservas: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void ExcluirReserva(string reserva)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_reserva where cd_reserva = " + reserva;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir a reserva: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void PesquisarReserva(string cd_reserva)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();
                string comando = "SELECT * from tb_reserva where cd_reserva = " + cd_reserva; 
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

    }
}
