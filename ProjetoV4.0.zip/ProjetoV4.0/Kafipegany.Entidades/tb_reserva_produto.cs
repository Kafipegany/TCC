﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_reserva_produto
    {
       
        private int id_reserva;
        private int id_produto;


        //] get set (encapsulamento)

        public int Id_reserva { get => id_reserva; set => id_reserva = value; }
        public int Id_produto { get => id_produto; set => id_produto = value; }


    }
}
