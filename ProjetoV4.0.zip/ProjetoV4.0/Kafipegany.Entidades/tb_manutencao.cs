﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_manutencao
    {
        private int cd_manutencao;
        private string ds_manutencao;
        private string ds_estadoUH;
        private string dt_inicio;
        private string dt_fim;

        // get set (encapsulamento)

        public int Cd_manutencao { get => cd_manutencao; set => cd_manutencao = value; }
        public string Ds_manutencao { get => ds_manutencao; set => ds_manutencao = value; }
        public string Ds_estadoUH { get => ds_estadoUH; set => ds_estadoUH = value; }
        public string Dt_inicio { get => dt_inicio; set => dt_inicio = value; }
        public string Dt_fim { get => dt_fim; set => dt_fim = value; }
    }
}
