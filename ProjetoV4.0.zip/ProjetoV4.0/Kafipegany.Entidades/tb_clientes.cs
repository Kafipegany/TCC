﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_clientes
    {
        private int cd_cliente;
        private string nm_cliente;
        private string cd_rg;
        private string cd_cpf;
        private string dt_nascimento;
        private string ds_telefone;
        private string ds_celular;
        private string ds_email;
        private string ds_estadocivil;
        private string ds_veiculo;
        private string ds_tipoVeiculo;
        private string cd_cnpj;
        private string cd_inscricaoEstadual;
        private string cd_placaVeiculo;
        private string cd_cep;
        private string nm_estado;
        private string nm_cidade;
        private string ds_endereco;
        private string nm_bairro;

        //get e set (emcapsulamento)

        public int Cd_cliente { get => cd_cliente; set => cd_cliente = value; }
        public string Nm_cliente { get => nm_cliente; set => nm_cliente = value; }
        public string Cd_rg { get => cd_rg; set => cd_rg = value; }
        public string Cd_cpf { get => cd_cpf; set => cd_cpf = value; }
        public string Dt_nascimento { get => dt_nascimento; set => dt_nascimento = value; }
        public string Ds_telefone { get => ds_telefone; set => ds_telefone = value; }
        public string Ds_celular { get => ds_celular; set => ds_celular = value; }
        public string Ds_email { get => ds_email; set => ds_email = value; }
        public string Ds_estadocivil { get => ds_estadocivil; set => ds_estadocivil = value; }
        public string Ds_veiculo { get => ds_veiculo; set => ds_veiculo = value; }
        public string Ds_tipoVeiculo { get => ds_tipoVeiculo; set => ds_tipoVeiculo = value; }
        public string Cd_cnpj { get => cd_cnpj; set => cd_cnpj = value; }
        public string Cd_inscricaoEstadual { get => cd_inscricaoEstadual; set => cd_inscricaoEstadual = value; }
        public string Cd_placaVeiculo { get => cd_placaVeiculo; set => cd_placaVeiculo = value; }
        public string Cd_cep { get => cd_cep; set => cd_cep = value; }
        public string Nm_estado { get => nm_estado; set => nm_estado = value; }
        public string Nm_cidade { get => nm_cidade; set => nm_cidade = value; }
        public string Ds_endereco { get => ds_endereco; set => ds_endereco = value; }
        public string Nm_bairro { get => nm_bairro; set => nm_bairro = value; }
    }
}
